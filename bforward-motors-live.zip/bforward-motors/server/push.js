'use strict';
// Web Push: alerts that reach a phone or computer even when the website is closed.
// Turned on only when VAPID keys are set. If the web-push package or keys are missing,
// everything else keeps working and in-page alerts still arrive.
const cfg = require('./config');
const db = require('./db');

let webpush = null;
try { webpush = require('web-push'); } catch (e) { webpush = null; }

let ready = false;
function init() {
  if (!webpush || !cfg.vapidPublic || !cfg.vapidPrivate) { console.log('Push alerts are off (no VAPID keys). In-page alerts still work.'); return; }
  const subject = cfg.vapidSubject || (cfg.adminEmail ? 'mailto:' + cfg.adminEmail : 'mailto:admin@example.com');
  webpush.setVapidDetails(subject, cfg.vapidPublic, cfg.vapidPrivate);
  ready = true;
  console.log('Push alerts are on.');
}
const enabled = () => ready;

async function send(subs, payload) {
  const body = JSON.stringify(payload);
  await Promise.all(subs.map(async (s) => {
    try {
      await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, body, { TTL: 3600 });
    } catch (e) {
      if (e && (e.statusCode === 404 || e.statusCode === 410)) await db.query('DELETE FROM push_subscriptions WHERE id = $1', [s.id]).catch(() => {});
    }
  }));
}

// target: { all: true } customers | { admins: true } | { userId }
async function notify(target, payload) {
  if (!ready) return;
  try {
    let rows;
    if (target.admins) rows = (await db.query("SELECT s.* FROM push_subscriptions s JOIN users u ON u.id = s.user_id WHERE u.role = 'admin'")).rows;
    else if (target.all) rows = (await db.query("SELECT s.* FROM push_subscriptions s JOIN users u ON u.id = s.user_id WHERE u.role = 'customer'")).rows;
    else rows = (await db.query('SELECT * FROM push_subscriptions WHERE user_id = $1', [target.userId])).rows;
    await send(rows, payload);
  } catch (e) { console.error('Push failed:', e.message); }
}

module.exports = { init, enabled, notify };
