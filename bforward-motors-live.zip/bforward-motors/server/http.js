'use strict';
// Small HTTP helpers: errors, cookies, JSON bodies, rate limiting and a tiny router.
// Kept dependency-free on purpose so there is less to install and less to break.

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach((part) => {
    const i = part.indexOf('=');
    if (i < 0) return;
    const k = part.slice(0, i).trim();
    if (k) { try { out[k] = decodeURIComponent(part.slice(i + 1).trim()); } catch (e) { /* ignore bad cookie */ } }
  });
  return out;
}

function cookieHeader(name, value, o) {
  o = o || {};
  let s = name + '=' + encodeURIComponent(value) + '; Path=/; HttpOnly; SameSite=Lax';
  if (o.maxAge != null) s += '; Max-Age=' + Math.floor(o.maxAge);
  if (o.secure) s += '; Secure';
  return s;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0, over = false;
    req.on('data', (c) => {
      size += c.length;
      if (over) { if (size > 25 * 1024 * 1024) req.destroy(); return; }   // keep draining so the client can read our 413
      if (size > limit) { over = true; chunks.length = 0; return; }
      chunks.push(c);
    });
    req.on('end', () => (over ? reject(new HttpError(413, 'That upload is too large.')) : resolve(Buffer.concat(chunks))));
    req.on('error', reject);
  });
}

async function readJson(req, limit) {
  const buf = await readBody(req, limit || 20 * 1024);
  if (!buf.length) return {};
  if (!/application\/json/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'Send the request as JSON.');
  try {
    const v = JSON.parse(buf.toString('utf8'));
    if (v === null || typeof v !== 'object' || Array.isArray(v)) throw new Error('shape');
    return v;
  } catch (e) { throw new HttpError(400, 'The request could not be read.'); }
}

function clientIp(req, trustProxy) {
  if (trustProxy) {
    const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (xf) return xf;
  }
  return req.socket.remoteAddress || 'unknown';
}

/* ---- rate limiting (in memory, per server instance) ---- */
const hits = new Map();
function rate(key, max, windowMs) {
  const now = Date.now();
  let h = hits.get(key);
  if (!h || h.reset < now) { h = { n: 0, reset: now + windowMs }; hits.set(key, h); }
  h.n++;
  if (h.n > max) throw new HttpError(429, 'Too many attempts. Wait a few minutes and try again.');
}
const sweeper = setInterval(() => { const now = Date.now(); hits.forEach((v, k) => { if (v.reset < now) hits.delete(k); }); }, 60 * 1000);
sweeper.unref();

/* ---- router ---- */
class Router {
  constructor() { this.routes = []; }
  add(method, pattern, opts, handler) {
    if (typeof opts === 'function') { handler = opts; opts = {}; }
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:([a-zA-Z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    this.routes.push({ method, re, keys, opts: opts || {}, handler });
  }
  get(p, o, h) { this.add('GET', p, o, h); }
  post(p, o, h) { this.add('POST', p, o, h); }
  put(p, o, h) { this.add('PUT', p, o, h); }
  patch(p, o, h) { this.add('PATCH', p, o, h); }
  del(p, o, h) { this.add('DELETE', p, o, h); }
  match(method, pathname) {
    let pathMatched = false;
    for (const r of this.routes) {
      const m = r.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (r.method !== method) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      return { route: r, params };
    }
    return { route: null, pathMatched };
  }
}

module.exports = { HttpError, parseCookies, cookieHeader, readBody, readJson, clientIp, rate, Router };
