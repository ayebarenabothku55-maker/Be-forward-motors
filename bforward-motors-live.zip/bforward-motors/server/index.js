'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const db = require('./db');
const auth = require('./auth');
const push = require('./push');
const { HttpError, Router, readJson, clientIp } = require('./http');

const router = new Router();
require('./routes/public')(router);
require('./routes/auth')(router);
require('./routes/shop')(router);
require('./routes/admin')(router);

const CSP = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
  "font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; " +
  "base-uri 'self'; form-action 'self'; object-src 'none'";

function securityHeaders(res) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (cfg.isProd) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function sendJson(res, status, obj, cache) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body), 'Cache-Control': cache || 'no-store' });
  res.end(body);
}

/* ---------------- API ---------------- */
async function handleApi(req, res, url) {
  const method = req.method;
  if (method !== 'GET' && method !== 'HEAD') {
    // Browsers always send Origin on cross-site writes. Refuse any that is not this site.
    const origin = req.headers.origin;
    if (origin) {
      let ok = false;
      try { ok = new URL(origin).host === req.headers.host; } catch (e) { ok = false; }
      if (!ok) throw new HttpError(403, 'Blocked request.');
    }
  }
  const m = router.match(method === 'HEAD' ? 'GET' : method, url.pathname);
  if (!m.route) throw new HttpError(m.pathMatched ? 405 : 404, m.pathMatched ? 'That action is not allowed.' : 'Not found.');

  const route = m.route;
  const c = {
    req, res, params: m.params, query: Object.fromEntries(url.searchParams), ip: clientIp(req, cfg.trustProxy),
    user: null, status: 200, cache: null, keepOpen: false,
    body: (limit) => readJson(req, limit || route.opts.bodyLimit)
  };

  const level = route.opts.auth;
  if (level) {
    c.user = await auth.userFromRequest(req);
    if (level === 'user') auth.requireRole(c.user);
    else if (level === 'customer' || level === 'admin') auth.requireRole(c.user, level);
  }

  const result = await route.handler(c);
  if (res.writableEnded || c.keepOpen) return;
  if (result === undefined) { res.writeHead(204); res.end(); return; }
  sendJson(res, c.status, result, c.cache);
}

function sendError(req, res, e) {
  const status = e instanceof HttpError ? e.status : 500;
  if (status === 500) console.error('Server error on ' + req.method + ' ' + req.url + ':', e && e.stack ? e.stack : e);
  if (res.headersSent) { try { res.end(); } catch (_) { /* socket gone */ } return; }
  const message = e instanceof HttpError ? e.message : 'Something went wrong on our side. Please try again.';
  if (req.url.startsWith('/api/')) sendJson(res, status, { error: message });
  else {
    res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Not found</title>' +
      '<body style="font-family:system-ui,sans-serif;max-width:32rem;margin:15vh auto;padding:0 1rem"><h1>' + (status === 404 ? 'Page not found' : 'Error') + '</h1><p>' + message + '</p><p><a href="/">Back to B Forward Motors</a></p></body>');
  }
}

/* ---------------- static files ---------------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json'
};

let nameIndex = null;
function findByName(name) {
  if (!/^[\w.-]+\.(html|css|js|svg|txt|png|jpg)$/i.test(name)) return null;
  if (!nameIndex) {
    nameIndex = {};
    const root = path.join(__dirname, '..');
    const walk = (dir, depth) => {
      if (depth > 4) return;
      let list = [];
      try { list = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
      for (const d of list) {
        if (d.name === 'node_modules' || d.name === '.git' || d.name === 'server' || d.name === 'test') continue;
        const full = path.join(dir, d.name);
        if (d.isDirectory()) walk(full, depth + 1);
        else if (!(d.name in nameIndex)) nameIndex[d.name] = full;
      }
    };
    walk(root, 0);
  }
  return nameIndex[name] || null;
}

function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'That action is not allowed.');
  let p;
  try { p = decodeURIComponent(url.pathname); } catch (e) { throw new HttpError(400, 'Bad address.'); }
  if (p === '/') p = '/index.html'; else if (!path.extname(p)) p += '.html';
  let file = path.normalize(path.join(cfg.publicDir, p));
  if (!file.startsWith(cfg.publicDir + path.sep)) throw new HttpError(404, 'We could not find that page.');
  let st;
  try { st = fs.statSync(file); } catch (e) { st = null; }
  if (!st || !st.isFile()) {
    // Forgiving fallback: if the site files were uploaded to git in the wrong folders,
    // find the file by name elsewhere in the project so the site still renders.
    const alt = findByName(path.basename(p));
    if (!alt) throw new HttpError(404, 'We could not find that page.');
    file = alt; st = fs.statSync(file);
  }
  const etag = '"' + st.size.toString(16) + '-' + Math.floor(st.mtimeMs).toString(16) + '"';
  const headers = { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', ETag: etag, 'Cache-Control': 'no-cache' };
  if (p === '/sw.js') headers['Service-Worker-Allowed'] = '/';
  if (req.headers['if-none-match'] === etag) { res.writeHead(304, headers); res.end(); return; }
  headers['Content-Length'] = st.size;
  res.writeHead(200, headers);
  if (req.method === 'HEAD') { res.end(); return; }
  fs.createReadStream(file).pipe(res);
}

async function handle(req, res) {
  securityHeaders(res);
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) await handleApi(req, res, url);
    else serveStatic(req, res, url);
  } catch (e) { sendError(req, res, e); }
}

/* ---------------- start ---------------- */
async function cleanup() {
  try { await db.query("DELETE FROM events WHERE created_at < now() - interval '180 days'"); } catch (e) { console.error('Cleanup failed:', e.message); }
}

async function start(opts) {
  opts = opts || {};
  cfg.check();
  await db.migrate();
  await auth.bootstrapAdmin();
  push.init();
  const server = http.createServer((req, res) => { handle(req, res); });
  server.keepAliveTimeout = 65000;
  server.headersTimeout = 66000;
  await new Promise((resolve) => server.listen(opts.port != null ? opts.port : cfg.port, '0.0.0.0', resolve));
  const timer = setInterval(cleanup, 6 * 3600e3); timer.unref();
  cleanup();
  return {
    server, port: server.address().port,
    close: async () => { clearInterval(timer); server.closeAllConnections && server.closeAllConnections(); await new Promise((r) => server.close(r)); await db.close(); }
  };
}

module.exports = { start };

if (require.main === module) {
  start().then((s) => {
    console.log('B Forward Motors is running on port ' + s.port);
    const stop = () => { console.log('Shutting down...'); setTimeout(() => process.exit(0), 4000).unref(); s.close().then(() => process.exit(0), () => process.exit(1)); };
    process.on('SIGTERM', stop); process.on('SIGINT', stop);
  }).catch((e) => { console.error('Failed to start:', e); process.exit(1); });
}
