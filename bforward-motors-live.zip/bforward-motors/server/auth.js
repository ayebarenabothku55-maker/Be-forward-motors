'use strict';
const crypto = require('crypto');
const { promisify } = require('util');
const cfg = require('./config');
const db = require('./db');
const { HttpError, parseCookies, cookieHeader } = require('./http');

const scrypt = promisify(crypto.scrypt);
const COOKIE = 'bf_session';
const SESSION_MS = 30 * 24 * 3600 * 1000;

/* ---- passwords: scrypt with a random salt ---- */
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, 64);
  return 'scrypt$' + salt.toString('base64') + '$' + key.toString('base64');
}
async function verifyPassword(pw, stored) {
  const parts = String(stored || '').split('$');
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
  const salt = Buffer.from(parts[1], 'base64'), want = Buffer.from(parts[2], 'base64');
  const got = await scrypt(pw, salt, want.length);
  return crypto.timingSafeEqual(got, want);
}
let dummyHash = null;
async function burnTime(pw) {   // makes "no such user" take as long as "wrong password"
  if (!dummyHash) dummyHash = await hashPassword('not-a-real-password');
  await verifyPassword(pw, dummyHash);
}

/* ---- signed session cookie ---- */
function b64u(buf) { return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
function sign(payload) {
  const body = b64u(JSON.stringify(payload));
  const mac = b64u(crypto.createHmac('sha256', cfg.sessionSecret).update(body).digest());
  return body + '.' + mac;
}
function unsign(token) {
  const i = String(token || '').indexOf('.');
  if (i < 1) return null;
  const body = token.slice(0, i), mac = token.slice(i + 1);
  const want = b64u(crypto.createHmac('sha256', cfg.sessionSecret).update(body).digest());
  const a = Buffer.from(mac), b = Buffer.from(want);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const p = JSON.parse(Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    return p.exp > Date.now() ? p : null;
  } catch (e) { return null; }
}

function isSecure(req) {
  return cfg.isProd || (cfg.trustProxy && req.headers['x-forwarded-proto'] === 'https');
}
function startSession(req, res, user) {
  const token = sign({ u: user.id, tv: user.token_version, exp: Date.now() + SESSION_MS });
  res.setHeader('Set-Cookie', cookieHeader(COOKIE, token, { maxAge: SESSION_MS / 1000, secure: isSecure(req) }));
}
function endSession(req, res) {
  res.setHeader('Set-Cookie', cookieHeader(COOKIE, '', { maxAge: 0, secure: isSecure(req) }));
}

async function userFromRequest(req) {
  const tok = parseCookies(req.headers.cookie)[COOKIE];
  const p = unsign(tok);
  if (!p) return null;
  const { rows } = await db.query('SELECT id, name, email, phone, role, token_version, notif_seen_at, created_at FROM users WHERE id = $1', [p.u]);
  const u = rows[0];
  if (!u || u.token_version !== p.tv) return null;
  return u;
}

function publicUser(u) { return { id: u.id, name: u.name, email: u.email, phone: u.phone, role: u.role }; }

function requireRole(user, role) {
  if (!user) throw new HttpError(401, 'Please log in to continue.');
  if (role && user.role !== role) throw new HttpError(403, 'You do not have access to that.');
}

/* ---- first admin comes from environment variables ---- */
async function bootstrapAdmin() {
  if (!cfg.adminEmail || !cfg.adminPassword) return;
  const { rows } = await db.query('SELECT id, role FROM users WHERE lower(email) = $1', [cfg.adminEmail]);
  if (!rows.length) {
    await db.query("INSERT INTO users (name, email, password_hash, role) VALUES ($1, $2, $3, 'admin')", ['Administrator', cfg.adminEmail, await hashPassword(cfg.adminPassword)]);
    console.log('Created admin account for ' + cfg.adminEmail);
  } else {
    if (rows[0].role !== 'admin') await db.query("UPDATE users SET role = 'admin' WHERE id = $1", [rows[0].id]);
    if (cfg.adminReset) {
      await db.query('UPDATE users SET password_hash = $2, token_version = token_version + 1 WHERE id = $1', [rows[0].id, await hashPassword(cfg.adminPassword)]);
      console.log('Admin password reset from ADMIN_PASSWORD. Remove ADMIN_RESET_PASSWORD now.');
    }
  }
}

module.exports = { hashPassword, verifyPassword, burnTime, startSession, endSession, userFromRequest, publicUser, requireRole, bootstrapAdmin };
