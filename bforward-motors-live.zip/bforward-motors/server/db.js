'use strict';
const fs = require('fs');
const path = require('path');
const pg = require('pg');
const cfg = require('./config');

// Return numbers and plain dates instead of strings / JS Date objects for these types.
pg.types.setTypeParser(20, (v) => parseInt(v, 10));   // BIGINT
pg.types.setTypeParser(1700, (v) => parseFloat(v));   // NUMERIC
pg.types.setTypeParser(1082, (v) => v);               // DATE stays 'YYYY-MM-DD'

function wantSsl(url) {
  if (cfg.databaseSsl === 'true') return { rejectUnauthorized: false };
  if (cfg.databaseSsl === 'false') return false;
  try {
    const host = new URL(url).hostname;
    // Render's internal hostnames have no dots; local databases need no TLS.
    if (!host.includes('.') || host === 'localhost' || host === '127.0.0.1') return false;
  } catch (e) { return false; }
  return { rejectUnauthorized: false };
}

let pool = null;
function getPool() {
  if (!pool) {
    pool = new pg.Pool({ connectionString: cfg.databaseUrl, ssl: wantSsl(cfg.databaseUrl), max: 10, idleTimeoutMillis: 30000, connectionTimeoutMillis: 10000 });
    pool.on('error', (e) => console.error('Database connection error:', e.message));
  }
  return pool;
}

const query = (text, params) => getPool().query(text, params);

async function tx(fn) {
  const c = await getPool().connect();
  try {
    await c.query('BEGIN');
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    try { await c.query('ROLLBACK'); } catch (_) { /* connection already gone */ }
    throw e;
  } finally { c.release(); }
}

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  const c = await getPool().connect();
  try {
    await c.query('SELECT pg_advisory_lock(727274)');   // one instance migrates at a time
    await c.query(sql);
  } finally {
    try { await c.query('SELECT pg_advisory_unlock(727274)'); } catch (_) { /* ignore */ }
    c.release();
  }
}

async function close() { if (pool) { const p = pool; pool = null; await p.end(); } }

module.exports = { query, tx, migrate, close };
