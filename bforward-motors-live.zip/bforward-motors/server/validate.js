'use strict';
const { HttpError } = require('./http');
const bad = (m) => new HttpError(400, m);

exports.str = function (v, label, min, max) {
  if (typeof v !== 'string') throw bad(label + ' is required.');
  const s = v.trim();
  if (s.length < min) throw bad(min <= 1 ? label + ' is required.' : label + ' must be at least ' + min + ' characters.');
  if (s.length > max) throw bad(label + ' is too long (maximum ' + max + ' characters).');
  return s;
};

exports.optStr = function (v, label, max) {
  if (v == null || v === '') return '';
  return exports.str(v, label, 0, max);
};

exports.int = function (v, label, min, max) {
  const n = typeof v === 'string' && v.trim() !== '' ? Number(v) : v;
  if (!Number.isInteger(n) || n < min || n > max) throw bad(label + ' must be a whole number between ' + min + ' and ' + max + '.');
  return n;
};

exports.email = function (v) {
  const s = exports.str(v, 'Email', 3, 120).toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s)) throw bad('Enter a valid email address.');
  return s;
};

exports.phone = function (v) {
  if (v == null || v === '') return '';
  const s = exports.str(v, 'Phone', 0, 30);
  if (!/^[0-9+()\-\s]{7,30}$/.test(s)) throw bad('Enter a valid phone number, for example +256 700 000 000.');
  return s;
};

exports.password = function (v, label) {
  if (typeof v !== 'string' || v.length < 8) throw bad((label || 'Password') + ' must be at least 8 characters.');
  if (v.length > 128) throw bad((label || 'Password') + ' is too long.');
  return v;
};

exports.oneOf = function (v, list, label) {
  if (!list.includes(v)) throw bad(label + ' must be one of: ' + list.join(', ') + '.');
  return v;
};

exports.id = function (v, label) {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1 || n > 2147483647) throw new HttpError(404, (label || 'Item') + ' not found.');
  return n;
};
