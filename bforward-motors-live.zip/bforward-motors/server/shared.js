'use strict';
const db = require('./db');
const realtime = require('./realtime');
const push = require('./push');

const FUELS = ['Petrol', 'Diesel', 'Hybrid', 'Electric'];
const GEARBOXES = ['Automatic', 'Manual', '4WD Automatic', '4WD Manual'];
const VISIT_TIMES = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'];

// Columns sent to the browser for a car (never the photo bytes).
function productCols(a) {
  a = a ? a + '.' : '';
  return a + 'id, ' + a + 'make, ' + a + 'model, ' + a + 'year, ' + a + 'price, ' + a + 'km, ' + a + 'fuel, ' + a + 'trans, ' + a + 'color, ' +
    a + 'color_name AS "colorName", ' + a + 'description, ' + a + 'status, (' + a + 'image IS NOT NULL) AS "hasImage", ' +
    a + 'image_v AS "imageV", ' + a + 'created_at AS "createdAt"';
}

// Today's date in Uganda (UTC+3, no daylight saving).
function todayKampala(offsetDays) {
  return new Date(Date.now() + 3 * 3600e3 + (offsetDays || 0) * 864e5).toISOString().slice(0, 10);
}

async function getSettings() {
  const { rows } = await db.query('SELECT key, value FROM settings');
  const s = {}; rows.forEach((r) => { s[r.key] = r.value; });
  return s;
}

// Save a notification for every customer, then tell everyone online and push to phones.
async function createNotification(title, body, productId) {
  const { rows } = await db.query(
    'INSERT INTO notifications (title, body, product_id) VALUES ($1, $2, $3) RETURNING id, title, body, product_id AS "productId", created_at AS "createdAt"',
    [title, body, productId || null]);
  const n = rows[0];
  realtime.toCustomers('notification', n);
  push.notify({ all: true }, { title: title, body: body, url: n.productId ? '/shop#car=' + n.productId : '/shop' });
  return n;
}

module.exports = { FUELS, GEARBOXES, VISIT_TIMES, productCols, todayKampala, getSettings, createNotification };
