'use strict';
// Server-Sent Events: the browser keeps one open connection and the server pushes
// new chat messages, notifications and status changes down it instantly.
// This keeps connections in this process's memory, so run a single web instance
// (see README for what to change if you ever scale to several).

const clients = new Set();   // { res, userId, role }

function add(res, user) {
  const c = { res, userId: user.id, role: user.role };
  clients.add(c);
  res.on('close', () => clients.delete(c));
  return c;
}

function write(c, event, data) {
  try { c.res.write('event: ' + event + '\ndata: ' + JSON.stringify(data) + '\n\n'); } catch (e) { clients.delete(c); }
}

function toUser(userId, event, data) { clients.forEach((c) => { if (c.userId === userId) write(c, event, data); }); }
function toAdmins(event, data) { clients.forEach((c) => { if (c.role === 'admin') write(c, event, data); }); }
function toCustomers(event, data) { clients.forEach((c) => { if (c.role === 'customer') write(c, event, data); }); }
function toAll(event, data) { clients.forEach((c) => write(c, event, data)); }
function isOnline(userId) { for (const c of clients) if (c.userId === userId) return true; return false; }
function count() { return clients.size; }

const beat = setInterval(() => { clients.forEach((c) => { try { c.res.write(': ping\n\n'); } catch (e) { clients.delete(c); } }); }, 25000);
beat.unref();

module.exports = { add, toUser, toAdmins, toCustomers, toAll, isOnline, count };
