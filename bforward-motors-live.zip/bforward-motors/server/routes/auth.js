'use strict';
const db = require('../db');
const V = require('../validate');
const auth = require('../auth');
const { HttpError, rate } = require('../http');

module.exports = function (r) {
  r.post('/api/auth/signup', async (c) => {
    rate('signup:' + c.ip, 10, 3600e3);
    const b = await c.body();
    const name = V.str(b.name, 'Name', 2, 80);
    const email = V.email(b.email);
    const phone = V.phone(b.phone);
    const pw = V.password(b.password);
    const hash = await auth.hashPassword(pw);
    let user;
    try {
      const { rows } = await db.query(
        'INSERT INTO users (name, email, phone, password_hash) VALUES ($1, $2, $3, $4) RETURNING id, name, email, phone, role, token_version',
        [name, email, phone, hash]);
      user = rows[0];
    } catch (e) {
      if (e.code === '23505') throw new HttpError(409, 'An account with this email already exists. Log in instead.');
      throw e;
    }
    auth.startSession(c.req, c.res, user);
    c.status = 201;
    return { user: auth.publicUser(user) };
  });

  r.post('/api/auth/login', async (c) => {
    const b = await c.body();
    const email = V.email(b.email);
    const pw = typeof b.password === 'string' ? b.password : '';
    rate('login-ip:' + c.ip, 30, 15 * 60e3);
    rate('login-email:' + email, 10, 15 * 60e3);
    const { rows } = await db.query('SELECT id, name, email, phone, role, token_version, password_hash FROM users WHERE lower(email) = $1', [email]);
    const u = rows[0];
    let ok = false;
    if (u) ok = await auth.verifyPassword(pw, u.password_hash); else await auth.burnTime(pw);
    if (!ok) throw new HttpError(401, 'Email or password is wrong.');
    auth.startSession(c.req, c.res, u);
    return { user: auth.publicUser(u) };
  });

  r.post('/api/auth/logout', async (c) => {
    auth.endSession(c.req, c.res);
    return { ok: true };
  });

  r.get('/api/auth/me', { auth: 'optional' }, async (c) => {
    c.cache = 'no-store';
    return { user: c.user ? auth.publicUser(c.user) : null };
  });

  r.post('/api/auth/password', { auth: 'user' }, async (c) => {
    rate('pw:' + c.user.id, 10, 3600e3);
    const b = await c.body();
    const next = V.password(b.next, 'New password');
    const { rows } = await db.query('SELECT password_hash FROM users WHERE id = $1', [c.user.id]);
    if (!(await auth.verifyPassword(String(b.current || ''), rows[0].password_hash))) throw new HttpError(400, 'Your current password is wrong.');
    const up = await db.query('UPDATE users SET password_hash = $2, token_version = token_version + 1 WHERE id = $1 RETURNING id, name, email, phone, role, token_version', [c.user.id, await auth.hashPassword(next)]);
    auth.startSession(c.req, c.res, up.rows[0]);   // keeps this browser logged in, signs out all others
    return { ok: true };
  });
};
