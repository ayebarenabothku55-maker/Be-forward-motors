'use strict';
const db = require('../db');
const V = require('../validate');
const auth = require('../auth');
const realtime = require('../realtime');
const push = require('../push');
const cfg = require('../config');
const { HttpError } = require('../http');
const { FUELS, GEARBOXES, productCols, createNotification, getSettings } = require('../shared');

const ORDER_STATUSES = ['awaiting_payment', 'payment_submitted', 'paid', 'delivered', 'cancelled'];
const BOOKING_STATUSES = ['pending', 'confirmed', 'completed', 'cancelled'];
const MAX_IMAGE = 1500 * 1024;

function readProduct(b) {
  const thisYear = new Date().getFullYear();
  const color = typeof b.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(b.color) ? b.color : '#0b3d91';
  return {
    make: V.str(b.make, 'Make', 1, 40),
    model: V.str(b.model, 'Model', 1, 60),
    year: V.int(b.year, 'Year', 1980, thisYear + 1),
    price: V.int(b.price, 'Price', 1, 1e12),
    km: V.int(b.km == null || b.km === '' ? 0 : b.km, 'Mileage', 0, 2000000),
    fuel: V.oneOf(b.fuel || 'Petrol', FUELS, 'Fuel'),
    trans: V.oneOf(b.trans || 'Automatic', GEARBOXES, 'Gearbox'),
    colorName: V.optStr(b.colorName, 'Colour name', 30),
    color,
    description: V.optStr(b.description, 'Details', 2000)
  };
}

function readImage(dataUrl) {
  if (!dataUrl) return null;
  const m = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl));
  if (!m) throw new HttpError(400, 'The photo must be a JPG, PNG or WebP picture.');
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > MAX_IMAGE) throw new HttpError(413, 'That photo is too large. Use a smaller picture.');
  return { type: m[1], data: buf };
}

module.exports = function (r) {
  const A = { auth: 'admin' };
  const BIG = { auth: 'admin', bodyLimit: 3 * 1024 * 1024 };

  /* ---------- dashboard ---------- */
  r.get('/api/admin/stats', A, async () => {
    const one = async (sql) => (await db.query(sql)).rows[0].n;
    const series = (await db.query(
      "WITH d AS (SELECT generate_series((now() AT TIME ZONE 'Africa/Kampala')::date - 13, (now() AT TIME ZONE 'Africa/Kampala')::date, interval '1 day')::date AS day) " +
      "SELECT to_char(d.day, 'YYYY-MM-DD') AS day, " +
      "(SELECT count(*)::int FROM events e WHERE e.type = 'visit' AND (e.created_at AT TIME ZONE 'Africa/Kampala')::date = d.day) AS visits, " +
      "(SELECT count(*)::int FROM events e WHERE e.type = 'cart' AND (e.created_at AT TIME ZONE 'Africa/Kampala')::date = d.day) AS carts, " +
      "(SELECT count(*)::int FROM bookings b WHERE (b.created_at AT TIME ZONE 'Africa/Kampala')::date = d.day) AS bookings, " +
      "(SELECT count(*)::int FROM orders o WHERE (o.created_at AT TIME ZONE 'Africa/Kampala')::date = d.day) AS orders " +
      'FROM d ORDER BY d.day')).rows;
    const settings = await getSettings();
    const methods = await one('SELECT count(*)::int AS n FROM payment_methods');
    const cars = await one('SELECT count(*)::int AS n FROM products');
    return {
      kpis: {
        carsAvailable: await one("SELECT count(*)::int AS n FROM products WHERE status = 'available'"),
        pendingBookings: await one("SELECT count(*)::int AS n FROM bookings WHERE status = 'pending'"),
        ordersToConfirm: await one("SELECT count(*)::int AS n FROM orders WHERE status IN ('awaiting_payment', 'payment_submitted')"),
        customers: await one("SELECT count(*)::int AS n FROM users WHERE role = 'customer'"),
        paidRevenue: await one("SELECT COALESCE(sum(total), 0)::bigint AS n FROM orders WHERE status IN ('paid', 'delivered')"),
        chatsWaiting: await one("SELECT count(*)::int AS n FROM (SELECT DISTINCT ON (customer_id) sender FROM messages ORDER BY customer_id, id DESC) m WHERE sender = 'customer'")
      },
      series,
      setup: {
        hasCars: cars > 0,
        hasContacts: !!(settings.phone || settings.whatsapp || settings.email),
        hasPayments: methods > 0,
        pushOn: push.enabled()
      }
    };
  });

  /* ---------- insights (what visitors do) ---------- */
  r.get('/api/admin/insights', A, async () => {
    const days = "created_at > now() - interval '30 days'";
    const count = async (type) => (await db.query("SELECT count(*)::int AS n FROM events WHERE type = $1 AND " + days, [type])).rows[0].n;
    const perCar = (await db.query(
      "SELECT p.id, p.year || ' ' || p.make || ' ' || p.model AS title, " +
      "(SELECT count(*)::int FROM events e WHERE e.product_id = p.id AND e.type = 'view' AND e.created_at > now() - interval '30 days') AS views, " +
      "(SELECT count(*)::int FROM events e WHERE e.product_id = p.id AND e.type = 'cart' AND e.created_at > now() - interval '30 days') AS carts, " +
      "(SELECT count(*)::int FROM bookings b WHERE b.product_id = p.id AND b.created_at > now() - interval '30 days') AS bookings " +
      'FROM products p ORDER BY views DESC, p.id LIMIT 12')).rows;
    const terms = (await db.query("SELECT query AS term, count(*)::int AS n FROM events WHERE type = 'search' AND " + days + ' GROUP BY query ORDER BY n DESC, query LIMIT 8')).rows;
    const hours = (await db.query(
      "SELECT extract(hour FROM created_at AT TIME ZONE 'Africa/Kampala')::int AS hour, count(*)::int AS n FROM events WHERE type IN ('view', 'cart') AND " + days + ' GROUP BY 1 ORDER BY 1')).rows;
    const funnel = {
      views: await count('view'), carts: await count('cart'),
      bookings: (await db.query("SELECT count(*)::int AS n FROM bookings WHERE " + days)).rows[0].n,
      orders: (await db.query("SELECT count(*)::int AS n FROM orders WHERE " + days)).rows[0].n
    };
    const stock = (await db.query("SELECT year || ' ' || make || ' ' || model || ' ' || fuel || ' ' || trans AS hay FROM products WHERE status = 'available'")).rows.map((x) => x.hay.toLowerCase());

    // Plain-language suggestions drawn from the numbers above.
    const tips = [];
    const avg = perCar.length ? perCar.reduce((s, x) => s + x.views, 0) / perCar.length : 0;
    perCar.forEach((x) => {
      const rate = x.views ? x.carts / x.views : 0;
      if (x.views >= 10 && x.views > avg * 1.2 && rate < 0.12) tips.push('The ' + x.title + ' gets many views (' + x.views + ') but few add-to-carts (' + Math.round(rate * 100) + '%). Check its price, photo and description.');
    });
    terms.forEach((t) => { if (t.n >= 3 && !stock.some((h) => h.indexOf(t.term) > -1)) tips.push('Customers search for "' + t.term + '" (' + t.n + ' times) but no available car matches. Consider stocking it.'); });
    if (hours.length) { const top = hours.slice().sort((a, b) => b.n - a.n)[0]; tips.push('Most car views happen around ' + String(top.hour).padStart(2, '0') + ':00. Post new cars and answer chats just before then.'); }
    const waiting = (await db.query("SELECT count(*)::int AS n FROM (SELECT DISTINCT ON (customer_id) sender FROM messages ORDER BY customer_id, id DESC) m WHERE sender = 'customer'")).rows[0].n;
    if (waiting) tips.push(waiting + ' customer' + (waiting > 1 ? 's are' : ' is') + ' waiting for a chat reply.');
    const pend = (await db.query("SELECT count(*)::int AS n FROM bookings WHERE status = 'pending'")).rows[0].n;
    if (pend) tips.push(pend + ' booking request' + (pend > 1 ? 's are' : ' is') + ' waiting for confirmation.');
    return { funnel, perCar, terms, hours, tips };
  });

  /* ---------- products ---------- */
  r.get('/api/admin/products', A, async () => {
    const { rows } = await db.query('SELECT ' + productCols() + ' FROM products ORDER BY created_at DESC, id DESC LIMIT 500');
    return { products: rows };
  });

  r.post('/api/admin/products', BIG, async (c) => {
    const b = await c.body();
    const p = readProduct(b), img = readImage(b.image);
    const { rows } = await db.query(
      'INSERT INTO products (make, model, year, price, km, fuel, trans, color, color_name, description, image, image_type, image_v) ' +
      'VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING ' + productCols(),
      [p.make, p.model, p.year, p.price, p.km, p.fuel, p.trans, p.color, p.colorName, p.description, img ? img.data : null, img ? img.type : null, img ? Date.now() : 0]);
    const car = rows[0];
    realtime.toAll('products', {});
    if (b.notify) await createNotification('New arrival: ' + car.year + ' ' + car.make + ' ' + car.model, 'Now available for UGX ' + Number(car.price).toLocaleString('en-US') + '. Tap to see it and book a test drive.', car.id);
    c.status = 201;
    return { product: car };
  });

  r.put('/api/admin/products/:id', BIG, async (c) => {
    const id = V.id(c.params.id, 'Car');
    const b = await c.body();
    const p = readProduct(b);
    let sql = 'UPDATE products SET make = $2, model = $3, year = $4, price = $5, km = $6, fuel = $7, trans = $8, color = $9, color_name = $10, description = $11, updated_at = now()';
    const args = [id, p.make, p.model, p.year, p.price, p.km, p.fuel, p.trans, p.color, p.colorName, p.description];
    if (b.removeImage) sql += ', image = NULL, image_type = NULL, image_v = 0';
    else if (b.image) { const img = readImage(b.image); args.push(img.data, img.type, Date.now()); sql += ', image = $12, image_type = $13, image_v = $14'; }
    const { rows } = await db.query(sql + ' WHERE id = $1 RETURNING ' + productCols(), args);
    if (!rows.length) throw new HttpError(404, 'Car not found.');
    realtime.toAll('products', {});
    return { product: rows[0] };
  });

  r.patch('/api/admin/products/:id/status', A, async (c) => {
    const id = V.id(c.params.id, 'Car');
    const status = V.oneOf((await c.body()).status, ['available', 'reserved', 'sold'], 'Status');
    const { rows } = await db.query('UPDATE products SET status = $2, updated_at = now() WHERE id = $1 RETURNING id', [id, status]);
    if (!rows.length) throw new HttpError(404, 'Car not found.');
    realtime.toAll('products', {});
    return { ok: true };
  });

  r.del('/api/admin/products/:id', A, async (c) => {
    const id = V.id(c.params.id, 'Car');
    const cur = await db.query('SELECT status FROM products WHERE id = $1', [id]);
    if (!cur.rows.length) throw new HttpError(404, 'Car not found.');
    if (cur.rows[0].status !== 'available' && c.query.force !== '1') throw new HttpError(409, 'This car is reserved or sold. Cancel its order or confirm that you want to delete it anyway.');
    await db.query('DELETE FROM products WHERE id = $1', [id]);
    realtime.toAll('products', {});
    return { ok: true };
  });

  /* ---------- bookings and orders ---------- */
  r.get('/api/admin/bookings', A, async () => {
    const { rows } = await db.query(
      'SELECT b.id, COALESCE(u.name, b.customer_name) AS customer, COALESCE(u.phone, b.customer_phone) AS phone, b.car_title AS "carTitle", ' +
      'b.visit_date AS date, b.visit_time AS time, b.note, b.status, b.created_at AS "createdAt" FROM bookings b LEFT JOIN users u ON u.id = b.user_id ORDER BY b.id DESC LIMIT 300');
    return { bookings: rows };
  });

  r.patch('/api/admin/bookings/:id', A, async (c) => {
    const id = V.id(c.params.id, 'Booking');
    const status = V.oneOf((await c.body()).status, BOOKING_STATUSES, 'Status');
    const { rows } = await db.query('UPDATE bookings SET status = $2 WHERE id = $1 RETURNING id, user_id, car_title', [id, status]);
    if (!rows.length) throw new HttpError(404, 'Booking not found.');
    if (rows[0].user_id) {
      realtime.toUser(rows[0].user_id, 'booking', { id, status, carTitle: rows[0].car_title });
      push.notify({ userId: rows[0].user_id }, { title: 'Booking ' + status, body: 'Your booking for the ' + rows[0].car_title + ' is now ' + status + '.', url: '/shop' });
    }
    return { ok: true };
  });

  r.get('/api/admin/orders', A, async () => {
    const { rows } = await db.query(
      'SELECT o.id, COALESCE(u.name, o.customer_name) AS customer, COALESCE(u.phone, o.customer_phone) AS phone, o.total, o.method, o.status, o.payment_ref AS "paymentRef", o.created_at AS "createdAt", ' +
      "COALESCE(json_agg(json_build_object('title', oi.title, 'price', oi.price) ORDER BY oi.id) FILTER (WHERE oi.id IS NOT NULL), '[]'::json) AS items " +
      'FROM orders o LEFT JOIN users u ON u.id = o.user_id LEFT JOIN order_items oi ON oi.order_id = o.id GROUP BY o.id, u.name, u.phone ORDER BY o.id DESC LIMIT 300');
    return { orders: rows };
  });

  r.patch('/api/admin/orders/:id', A, async (c) => {
    const id = V.id(c.params.id, 'Order');
    const status = V.oneOf((await c.body()).status, ORDER_STATUSES, 'Status');
    const out = await db.tx(async (t) => {
      const cur = await t.query('SELECT user_id, status FROM orders WHERE id = $1 FOR UPDATE', [id]);
      if (!cur.rows.length) throw new HttpError(404, 'Order not found.');
      const was = cur.rows[0];
      if (was.status === 'cancelled' && status !== 'cancelled') {
        const taken = await t.query("SELECT count(*)::int AS n FROM order_items oi JOIN products p ON p.id = oi.product_id WHERE oi.order_id = $1 AND p.status <> 'available'", [id]);
        if (taken.rows[0].n) throw new HttpError(409, 'One of these cars was reserved by another order after this one was cancelled.');
      }
      await t.query('UPDATE orders SET status = $2, updated_at = now() WHERE id = $1', [id, status]);
      const carStatus = status === 'cancelled' ? 'available' : (status === 'paid' || status === 'delivered') ? 'sold' : 'reserved';
      await t.query('UPDATE products SET status = $2, updated_at = now() WHERE id IN (SELECT product_id FROM order_items WHERE order_id = $1 AND product_id IS NOT NULL)', [id, carStatus]);
      return was;
    });
    realtime.toAll('products', {});
    if (out.user_id) {
      const label = status.replace('_', ' ');
      realtime.toUser(out.user_id, 'order', { id, status });
      push.notify({ userId: out.user_id }, { title: 'Order update', body: 'Your order is now: ' + label + '.', url: '/shop' });
    }
    return { ok: true };
  });

  /* ---------- users ---------- */
  r.get('/api/admin/users', A, async () => {
    const { rows } = await db.query(
      "SELECT u.id, u.name, u.email, u.phone, u.created_at AS \"createdAt\", (SELECT count(*)::int FROM bookings b WHERE b.user_id = u.id) AS bookings, " +
      "(SELECT count(*)::int FROM orders o WHERE o.user_id = u.id) AS orders FROM users u WHERE u.role = 'customer' ORDER BY u.id DESC LIMIT 500");
    return { users: rows };
  });

  r.del('/api/admin/users/:id', A, async (c) => {
    const id = V.id(c.params.id, 'User');
    const done = await db.tx(async (t) => {
      // Cars held by their unpaid orders go back on sale. Paid orders stay as sales records.
      await t.query("UPDATE products SET status = 'available', updated_at = now() WHERE id IN (SELECT oi.product_id FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE o.user_id = $1 AND o.status IN ('awaiting_payment', 'payment_submitted') AND oi.product_id IS NOT NULL)", [id]);
      await t.query("UPDATE orders SET status = 'cancelled', updated_at = now() WHERE user_id = $1 AND status IN ('awaiting_payment', 'payment_submitted')", [id]);
      return t.query("DELETE FROM users WHERE id = $1 AND role = 'customer' RETURNING id", [id]);
    });
    if (!done.rows.length) throw new HttpError(404, 'Customer not found.');
    realtime.toAll('products', {});
    return { ok: true };
  });

  r.post('/api/admin/users/:id/password', A, async (c) => {
    const id = V.id(c.params.id, 'User');
    const pw = V.password((await c.body()).password, 'New password');
    const { rows } = await db.query("UPDATE users SET password_hash = $2, token_version = token_version + 1 WHERE id = $1 AND role = 'customer' RETURNING id", [id, await auth.hashPassword(pw)]);
    if (!rows.length) throw new HttpError(404, 'Customer not found.');
    return { ok: true };
  });

  r.post('/api/admin/announcements', A, async (c) => {
    const b = await c.body();
    const n = await createNotification(V.str(b.title, 'Title', 2, 80), V.str(b.body, 'Message', 2, 300), null);
    c.status = 201;
    return { notification: n };
  });

  /* ---------- chat inbox ---------- */
  r.get('/api/admin/conversations', A, async () => {
    const { rows } = await db.query(
      'SELECT u.id, u.name, u.email, m.body AS "lastBody", m.created_at AS "lastAt", (m.sender = \'customer\') AS waiting ' +
      'FROM users u JOIN LATERAL (SELECT body, sender, created_at, id FROM messages WHERE customer_id = u.id ORDER BY id DESC LIMIT 1) m ON true ORDER BY m.id DESC LIMIT 200');
    return { conversations: rows };
  });

  r.get('/api/admin/messages/:customerId', A, async (c) => {
    const id = V.id(c.params.customerId, 'Customer');
    const { rows } = await db.query('SELECT id, sender, body, created_at AS "createdAt" FROM messages WHERE customer_id = $1 ORDER BY id DESC LIMIT 300', [id]);
    return { messages: rows.reverse() };
  });

  r.post('/api/admin/messages/:customerId', A, async (c) => {
    const id = V.id(c.params.customerId, 'Customer');
    const body = V.str((await c.body()).body, 'Message', 1, 1000);
    const who = await db.query("SELECT id FROM users WHERE id = $1 AND role = 'customer'", [id]);
    if (!who.rows.length) throw new HttpError(404, 'Customer not found.');
    const { rows } = await db.query("INSERT INTO messages (customer_id, sender, body) VALUES ($1, 'admin', $2) RETURNING id, sender, body, created_at AS \"createdAt\"", [id, body]);
    const m = Object.assign({ customerId: id }, rows[0]);
    realtime.toUser(id, 'message', m);
    realtime.toAdmins('message', m);
    if (!realtime.isOnline(id)) push.notify({ userId: id }, { title: 'B Forward Motors replied', body: body.slice(0, 120), url: '/shop' });
    c.status = 201;
    return { message: rows[0] };
  });

  /* ---------- feedback moderation ---------- */
  r.get('/api/admin/feedback', A, async () => {
    const { rows } = await db.query('SELECT id, name, rating, body AS text, approved, created_at AS "createdAt" FROM feedback ORDER BY id DESC LIMIT 300');
    return { feedback: rows };
  });
  r.patch('/api/admin/feedback/:id', A, async (c) => {
    const b = await c.body();
    await db.query('UPDATE feedback SET approved = $2 WHERE id = $1', [V.id(c.params.id, 'Feedback'), b.approved === true]);
    return { ok: true };
  });
  r.del('/api/admin/feedback/:id', A, async (c) => {
    await db.query('DELETE FROM feedback WHERE id = $1', [V.id(c.params.id, 'Feedback')]);
    return { ok: true };
  });

  /* ---------- payment methods and company details ---------- */
  function readMethod(b) {
    return [V.str(b.name, 'Name', 2, 60), V.optStr(b.details, 'Details', 300), V.optStr(b.note, 'Instruction', 300)];
  }
  r.post('/api/admin/payment-methods', A, async (c) => {
    const m = readMethod(await c.body());
    const { rows } = await db.query('INSERT INTO payment_methods (name, details, note, sort) VALUES ($1, $2, $3, COALESCE((SELECT max(sort) + 1 FROM payment_methods), 0)) RETURNING id, name, details, note', m);
    c.status = 201;
    return { paymentMethod: rows[0] };
  });
  r.put('/api/admin/payment-methods/:id', A, async (c) => {
    const m = readMethod(await c.body());
    const { rows } = await db.query('UPDATE payment_methods SET name = $2, details = $3, note = $4 WHERE id = $1 RETURNING id, name, details, note', [V.id(c.params.id, 'Payment method')].concat(m));
    if (!rows.length) throw new HttpError(404, 'Payment method not found.');
    return { paymentMethod: rows[0] };
  });
  r.del('/api/admin/payment-methods/:id', A, async (c) => {
    await db.query('DELETE FROM payment_methods WHERE id = $1', [V.id(c.params.id, 'Payment method')]);
    return { ok: true };
  });

  r.put('/api/admin/settings', A, async (c) => {
    const b = await c.body();
    const next = {
      business_name: V.str(b.business_name || 'B Forward Motors', 'Business name', 2, 80),
      phone: V.phone(b.phone),
      whatsapp: String(b.whatsapp || '').replace(/\D/g, ''),
      email: b.email ? V.email(b.email) : '',
      address: V.optStr(b.address, 'Address', 200),
      hours: V.optStr(b.hours, 'Opening hours', 120)
    };
    if (next.whatsapp && (next.whatsapp.length < 8 || next.whatsapp.length > 15)) throw new HttpError(400, 'WhatsApp number must include the country code, for example 256700000000.');
    for (const k of Object.keys(next)) {
      await db.query('INSERT INTO settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2', [k, next[k]]);
    }
    return { settings: await getSettings() };
  });

  r.get('/api/admin/info', A, async () => ({ pushEnabled: push.enabled(), vapidKey: push.enabled() ? cfg.vapidPublic : '', online: realtime.count() }));
};
