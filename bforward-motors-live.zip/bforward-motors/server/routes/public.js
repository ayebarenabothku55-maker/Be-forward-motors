'use strict';
const db = require('../db');
const V = require('../validate');
const push = require('../push');
const cfg = require('../config');
const { HttpError, rate } = require('../http');
const { productCols, getSettings } = require('../shared');

module.exports = function (r) {
  r.get('/api/health', async () => {
    await db.query('SELECT 1');
    const fs = require('fs'), path = require('path');
    const missing = ['index.html', 'css/style.css', 'js/common.js', 'js/public.js', 'js/shop.js', 'js/admin.js', 'js/login.js']
      .filter((f) => !fs.existsSync(path.join(cfg.publicDir, f)));
    return { ok: true, missingFiles: missing };
  });

  // Everything the public pages need to show business details and payment options.
  r.get('/api/config', async () => {
    const settings = await getSettings();
    const pm = await db.query('SELECT id, name, details, note FROM payment_methods ORDER BY sort, id');
    return { settings, paymentMethods: pm.rows, vapidKey: push.enabled() ? cfg.vapidPublic : '' };
  });

  r.get('/api/products', async (c) => {
    c.cache = 'no-cache';
    const { rows } = await db.query('SELECT ' + productCols() + ' FROM products ORDER BY created_at DESC, id DESC LIMIT 500');
    return { products: rows };
  });

  r.get('/api/products/:id/image', async (c) => {
    const id = V.id(c.params.id, 'Photo');
    const { rows } = await db.query('SELECT image, image_type FROM products WHERE id = $1 AND image IS NOT NULL', [id]);
    if (!rows.length) throw new HttpError(404, 'No photo.');
    c.res.writeHead(200, {
      'Content-Type': rows[0].image_type || 'image/jpeg',
      'Content-Length': rows[0].image.length,
      'Cache-Control': 'public, max-age=31536000, immutable'
    });
    c.res.end(rows[0].image);
  });

  r.get('/api/feedback', async () => {
    const { rows } = await db.query('SELECT id, name, rating, body AS text, created_at AS "createdAt" FROM feedback WHERE approved ORDER BY id DESC LIMIT 6');
    return { feedback: rows };
  });

  // Reviews are held until the admin approves them, so spam never shows on the site.
  r.post('/api/feedback', { auth: 'optional' }, async (c) => {
    rate('feedback:' + c.ip, 6, 3600e3);
    const b = await c.body();
    const name = V.str(b.name || (c.user ? c.user.name : 'Customer'), 'Name', 1, 60);
    const rating = V.int(b.rating, 'Rating', 1, 5);
    const text = V.str(b.text, 'Message', 5, 600);
    await db.query('INSERT INTO feedback (name, rating, body) VALUES ($1, $2, $3)', [name, rating, text]);
    return { ok: true };
  });

  // Visitor behaviour for the Insights page. The browser only calls this after the visitor allowed tracking.
  r.post('/api/track', { auth: 'optional' }, async (c) => {
    rate('track:' + c.ip, 240, 60e3);
    const b = await c.body(2000);
    const type = V.oneOf(b.type, ['visit', 'view', 'search', 'cart'], 'type');
    const visitor = String(b.visitor || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40);
    const pid = Number.isInteger(b.productId) ? b.productId : null;
    const q = type === 'search' ? String(b.query || '').trim().toLowerCase().slice(0, 60) : null;
    if (type === 'search' && !q) return;
    await db.query(
      'INSERT INTO events (type, visitor, user_id, product_id, query) VALUES ($1, $2, $3, (SELECT id FROM products WHERE id = $4::int), $5)',
      [type, visitor, c.user ? c.user.id : null, pid, q]);
    c.res.statusCode = 204; c.res.end();
  });
};
