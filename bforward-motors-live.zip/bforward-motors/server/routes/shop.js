'use strict';
const db = require('../db');
const V = require('../validate');
const realtime = require('../realtime');
const push = require('../push');
const { HttpError, rate } = require('../http');
const { productCols, todayKampala, VISIT_TIMES } = require('../shared');

const ORDER_SELECT =
  'SELECT o.id, o.total, o.method, o.status, o.payment_ref AS "paymentRef", o.created_at AS "createdAt", ' +
  "COALESCE(json_agg(json_build_object('title', oi.title, 'price', oi.price) ORDER BY oi.id) FILTER (WHERE oi.id IS NOT NULL), '[]'::json) AS items " +
  'FROM orders o LEFT JOIN order_items oi ON oi.order_id = o.id ';

module.exports = function (r) {
  const C = { auth: 'customer' };

  /* ---------- live stream ---------- */
  r.get('/api/stream', { auth: 'user' }, (c) => {
    c.res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
    c.res.write('retry: 4000\n\nevent: ready\ndata: {}\n\n');
    realtime.add(c.res, c.user);
    c.keepOpen = true;
  });

  /* ---------- cart ---------- */
  r.get('/api/cart', C, async (c) => {
    const { rows } = await db.query('SELECT ' + productCols('p') + ' FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.user_id = $1 ORDER BY ci.added_at', [c.user.id]);
    return { cart: rows };
  });

  r.post('/api/cart', C, async (c) => {
    const b = await c.body();
    const id = V.id(b.productId, 'Car');
    const p = await db.query('SELECT status FROM products WHERE id = $1', [id]);
    if (!p.rows.length) throw new HttpError(404, 'That car is no longer listed.');
    if (p.rows[0].status !== 'available') throw new HttpError(409, 'Sorry, this car is no longer available.');
    const n = await db.query('SELECT count(*)::int AS n FROM cart_items WHERE user_id = $1', [c.user.id]);
    if (n.rows[0].n >= 10) throw new HttpError(400, 'Your cart is full. Remove a car or place your order first.');
    const ins = await db.query('INSERT INTO cart_items (user_id, product_id) VALUES ($1, $2) ON CONFLICT DO NOTHING RETURNING product_id', [c.user.id, id]);
    return { added: ins.rows.length > 0 };
  });

  r.del('/api/cart/:productId', C, async (c) => {
    await db.query('DELETE FROM cart_items WHERE user_id = $1 AND product_id = $2', [c.user.id, V.id(c.params.productId, 'Car')]);
    return { ok: true };
  });

  /* ---------- test-drive bookings ---------- */
  r.get('/api/bookings', C, async (c) => {
    const { rows } = await db.query('SELECT id, car_title AS "carTitle", visit_date AS date, visit_time AS time, note, status, created_at AS "createdAt" FROM bookings WHERE user_id = $1 ORDER BY id DESC LIMIT 100', [c.user.id]);
    return { bookings: rows };
  });

  r.post('/api/bookings', C, async (c) => {
    rate('book:' + c.user.id, 12, 3600e3);
    const b = await c.body();
    const pid = V.id(b.productId, 'Car');
    const date = String(b.date || '');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(Date.parse(date + 'T00:00:00Z'))) throw new HttpError(400, 'Choose a valid date.');
    if (date < todayKampala()) throw new HttpError(400, 'Choose today or a later date.');
    if (date > todayKampala(180)) throw new HttpError(400, 'Choose a date within the next six months.');
    const time = V.oneOf(b.time, VISIT_TIMES, 'Time');
    const note = V.optStr(b.note, 'Note', 300);
    const p = await db.query('SELECT make, model, year, status FROM products WHERE id = $1', [pid]);
    if (!p.rows.length) throw new HttpError(404, 'That car is no longer listed.');
    if (p.rows[0].status !== 'available') throw new HttpError(409, 'Sorry, this car is no longer available.');
    const open = await db.query("SELECT count(*)::int AS n FROM bookings WHERE user_id = $1 AND status = 'pending'", [c.user.id]);
    if (open.rows[0].n >= 10) throw new HttpError(400, 'You already have several pending bookings. Wait for the team to confirm them.');
    const car = p.rows[0].year + ' ' + p.rows[0].make + ' ' + p.rows[0].model;
    const { rows } = await db.query(
      'INSERT INTO bookings (user_id, customer_name, customer_phone, product_id, car_title, visit_date, visit_time, note) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) ' +
      'RETURNING id, car_title AS "carTitle", visit_date AS date, visit_time AS time, note, status, created_at AS "createdAt"',
      [c.user.id, c.user.name, c.user.phone, pid, car, date, time, note]);
    realtime.toAdmins('badge', { kind: 'booking', text: c.user.name + ' booked the ' + car });
    push.notify({ admins: true }, { title: 'New booking', body: c.user.name + ' booked the ' + car + ' for ' + date + ' ' + time, url: '/admin#orders' });
    c.status = 201;
    return { booking: rows[0] };
  });

  /* ---------- orders ---------- */
  r.get('/api/orders', C, async (c) => {
    const { rows } = await db.query(ORDER_SELECT + 'WHERE o.user_id = $1 GROUP BY o.id ORDER BY o.id DESC LIMIT 100', [c.user.id]);
    return { orders: rows };
  });

  // Turns the cart into an order and reserves the cars in one step, so two buyers can never get the same car.
  r.post('/api/orders', C, async (c) => {
    rate('order:' + c.user.id, 10, 3600e3);
    const b = await c.body();
    const methods = (await db.query('SELECT id, name FROM payment_methods')).rows;
    let method = 'To be agreed with the team';
    if (methods.length) {
      const m = methods.filter((x) => x.id === Number(b.paymentMethodId))[0];
      if (!m) throw new HttpError(400, 'Choose a payment method.');
      method = m.name;
    }
    const order = await db.tx(async (t) => {
      const cart = await t.query('SELECT p.id, p.make, p.model, p.year, p.price, p.status FROM cart_items ci JOIN products p ON p.id = ci.product_id WHERE ci.user_id = $1 ORDER BY ci.added_at FOR UPDATE OF p', [c.user.id]);
      if (!cart.rows.length) throw new HttpError(400, 'Your cart is empty.');
      const gone = cart.rows.filter((p) => p.status !== 'available');
      if (gone.length) {
        await t.query('DELETE FROM cart_items WHERE user_id = $1 AND product_id = ANY($2::int[])', [c.user.id, gone.map((p) => p.id)]);
        throw new HttpError(409, 'Sorry, the ' + gone.map((p) => p.year + ' ' + p.make + ' ' + p.model).join(', ') + ' was just taken by another buyer. It was removed from your cart.');
      }
      const total = cart.rows.reduce((s, p) => s + p.price, 0);
      const o = await t.query('INSERT INTO orders (user_id, customer_name, customer_phone, total, method) VALUES ($1, $2, $3, $4, $5) RETURNING id', [c.user.id, c.user.name, c.user.phone, total, method]);
      for (const p of cart.rows) {
        await t.query('INSERT INTO order_items (order_id, product_id, title, price) VALUES ($1, $2, $3, $4)', [o.rows[0].id, p.id, p.year + ' ' + p.make + ' ' + p.model, p.price]);
      }
      await t.query("UPDATE products SET status = 'reserved', updated_at = now() WHERE id = ANY($1::int[])", [cart.rows.map((p) => p.id)]);
      await t.query('DELETE FROM cart_items WHERE user_id = $1', [c.user.id]);
      return { id: o.rows[0].id, total, count: cart.rows.length };
    });
    realtime.toAll('products', {});
    realtime.toAdmins('badge', { kind: 'order', text: c.user.name + ' placed an order' });
    push.notify({ admins: true }, { title: 'New order', body: c.user.name + ' ordered ' + order.count + ' car(s), total UGX ' + order.total.toLocaleString('en-US'), url: '/admin#orders' });
    const { rows } = await db.query(ORDER_SELECT + 'WHERE o.id = $1 GROUP BY o.id', [order.id]);
    c.status = 201;
    return { order: rows[0] };
  });

  // Customer pays outside the site (mobile money, bank, cash) and sends the reference so the team can confirm it.
  r.post('/api/orders/:id/payment', C, async (c) => {
    rate('payref:' + c.user.id, 20, 3600e3);
    const id = V.id(c.params.id, 'Order');
    const ref = V.str((await c.body()).reference, 'Payment reference', 3, 80);
    const { rows } = await db.query(
      "UPDATE orders SET payment_ref = $3, status = 'payment_submitted', updated_at = now() WHERE id = $1 AND user_id = $2 AND status IN ('awaiting_payment', 'payment_submitted') RETURNING id",
      [id, c.user.id, ref]);
    if (!rows.length) throw new HttpError(404, 'That order cannot take a payment reference.');
    realtime.toAdmins('badge', { kind: 'order', text: c.user.name + ' sent payment reference ' + ref });
    push.notify({ admins: true }, { title: 'Payment reference received', body: c.user.name + ': ' + ref, url: '/admin#orders' });
    return { ok: true };
  });

  /* ---------- notifications ---------- */
  r.get('/api/notifications', C, async (c) => {
    const { rows } = await db.query(
      'SELECT id, title, body, product_id AS "productId", created_at AS "createdAt", (created_at <= $1) AS "read" FROM notifications ORDER BY id DESC LIMIT 30',
      [c.user.notif_seen_at]);
    return { notifications: rows, unread: rows.filter((n) => !n.read).length };
  });

  r.post('/api/notifications/read', C, async (c) => {
    await db.query('UPDATE users SET notif_seen_at = now() WHERE id = $1', [c.user.id]);
    return { ok: true };
  });

  /* ---------- chat with the business ---------- */
  r.get('/api/messages', C, async (c) => {
    const { rows } = await db.query('SELECT id, sender, body, created_at AS "createdAt" FROM messages WHERE customer_id = $1 ORDER BY id DESC LIMIT 200', [c.user.id]);
    return { messages: rows.reverse() };
  });

  r.post('/api/messages', C, async (c) => {
    rate('msg:' + c.user.id, 40, 10 * 60e3);
    const body = V.str((await c.body()).body, 'Message', 1, 1000);
    const { rows } = await db.query("INSERT INTO messages (customer_id, sender, body) VALUES ($1, 'customer', $2) RETURNING id, sender, body, created_at AS \"createdAt\"", [c.user.id, body]);
    const m = rows[0];
    realtime.toAdmins('message', Object.assign({ customerId: c.user.id, customerName: c.user.name }, m));
    realtime.toUser(c.user.id, 'message', Object.assign({ customerId: c.user.id }, m));   // other tabs of the same customer
    push.notify({ admins: true }, { title: 'Message from ' + c.user.name, body: body.slice(0, 120), url: '/admin#messages' });
    c.status = 201;
    return { message: m };
  });

  /* ---------- phone / browser push subscription ---------- */
  r.post('/api/push/subscribe', { auth: 'user' }, async (c) => {
    const b = await c.body();
    const endpoint = V.str(b.endpoint, 'Endpoint', 10, 1000);
    const keys = b.keys || {};
    const p256dh = V.str(keys.p256dh, 'Key', 10, 200), authKey = V.str(keys.auth, 'Key', 10, 100);
    await db.query(
      'INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth) VALUES ($1, $2, $3, $4) ON CONFLICT (endpoint) DO UPDATE SET user_id = $1, p256dh = $3, auth = $4',
      [c.user.id, endpoint, p256dh, authKey]);
    return { ok: true };
  });

  r.post('/api/push/unsubscribe', { auth: 'user' }, async (c) => {
    await db.query('DELETE FROM push_subscriptions WHERE user_id = $1 AND endpoint = $2', [c.user.id, V.str((await c.body()).endpoint, 'Endpoint', 10, 1000)]);
    return { ok: true };
  });
};
