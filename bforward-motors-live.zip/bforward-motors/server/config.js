'use strict';
const path = require('path');
const crypto = require('crypto');
const env = process.env;

const isProd = env.NODE_ENV === 'production';

const cfg = {
  isProd,
  port: Number(env.PORT) || 3000,
  databaseUrl: env.DATABASE_URL || '',
  databaseSsl: env.DATABASE_SSL || '', // 'true' | 'false' | '' (auto)
  sessionSecret: env.SESSION_SECRET || '',
  adminEmail: (env.ADMIN_EMAIL || '').trim().toLowerCase(),
  adminPassword: env.ADMIN_PASSWORD || '',
  adminReset: env.ADMIN_RESET_PASSWORD === 'true',
  vapidPublic: env.VAPID_PUBLIC_KEY || '',
  vapidPrivate: env.VAPID_PRIVATE_KEY || '',
  vapidSubject: env.VAPID_SUBJECT || '',
  trustProxy: env.TRUST_PROXY ? env.TRUST_PROXY === 'true' : isProd,
  publicDir: path.join(__dirname, '..', 'public'),
  tz: 'Africa/Kampala'
};

// Fail early with a clear message instead of failing in a confusing way later.
cfg.check = function () {
  const problems = [];
  if (!cfg.databaseUrl) problems.push('DATABASE_URL is not set. Add your Postgres connection string.');
  if (isProd && cfg.sessionSecret.length < 32) problems.push('SESSION_SECRET must be set to a random value of at least 32 characters.');
  if (cfg.adminEmail && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(cfg.adminEmail)) problems.push('ADMIN_EMAIL is not a valid email address.');
  if (cfg.adminEmail && cfg.adminPassword.length < 10) problems.push('ADMIN_PASSWORD must be at least 10 characters.');
  if (problems.length) {
    console.error('\nConfiguration problems:\n - ' + problems.join('\n - ') + '\n');
    process.exit(1);
  }
  if (!cfg.sessionSecret) {
    cfg.sessionSecret = crypto.randomBytes(32).toString('hex');
    console.warn('SESSION_SECRET not set: using a temporary one. Everyone is logged out when the server restarts.');
  }
};

module.exports = cfg;
