(function () {
  'use strict';
  var $ = BF.$, E = BF.esc, M = BF.money;
  var QUICK = ['Price', 'Payment options', 'Book a test drive', 'Delivery', 'Talk to the business'];
  var TIMES = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'];
  var S = { user: null, cfg: null, products: [], cart: [], bookings: [], orders: [], notes: [], unread: 0, msgs: [], chatUnread: 0, panel: '', chatTab: 'biz', pay: 0 };

  BF.requireUser('customer').then(function (u) { if (u) boot(u); });

  function boot(u) {
    S.user = u;
    BF.consentBanner(); BF.track('visit'); BF.checkPush();
    $('#brand').outerHTML = BF.brand();
    $('#hello').textContent = 'Hi, ' + u.name.split(' ')[0];
    $('#bellIc').innerHTML = BF.ic('bell'); $('#chatIc').innerHTML = BF.ic('chat'); $('#cartIc').innerHTML = BF.ic('cart'); $('#outIc').innerHTML = BF.ic('logout');
    $('#panelX').innerHTML = BF.ic('x'); $('#botX').innerHTML = BF.ic('x'); $('#botBtn').innerHTML = BF.ic('chat');
    $('#outBtn').onclick = BF.logout;
    $('#bellBtn').onclick = function () { openPanel('notes'); };
    $('#cartBtn').onclick = function () { openPanel('cart'); };
    $('#chatBtn').onclick = function () { S.chatTab = 'biz'; openPanel('chat'); };
    $('#panelX').onclick = closePanel;
    $('#botBtn').onclick = function () { S.chatTab = 'bot'; $('#botFab').hidden = true; openPanel('chat'); };
    $('#botX').onclick = function () { $('#botBubble').hidden = true; };
    var st = botState(); if (st.on) { $('#botFab').hidden = false; $('#botBubble').hidden = true; }

    BF.config().then(function (c) { S.cfg = c; if (!S.pay && c.paymentMethods[0]) S.pay = c.paymentMethods[0].id; });
    refreshAll().then(function () {
      var m = /^#car=(\d+)$/.exec(location.hash);
      if (m) viewCar(+m[1]);
    });
    connect();
  }

  function fail(e) { BF.guard(e); }

  /* ---------- data loading ---------- */
  function loadProducts() { return BF.get('/products').then(function (r) { S.products = r.products; fillMakes(); drawCars(); }); }
  function loadCart() { return BF.get('/cart').then(function (r) { S.cart = r.cart; counts(); if (S.panel === 'cart') renderCart(); }); }
  function loadMine() {
    return Promise.all([BF.get('/bookings'), BF.get('/orders')]).then(function (r) { S.bookings = r[0].bookings; S.orders = r[1].orders; drawMine(); });
  }
  function loadNotes() { return BF.get('/notifications').then(function (r) { S.notes = r.notifications; S.unread = r.unread; counts(); if (S.panel === 'notes') renderNotes(true); }); }
  function loadMsgs() {
    return BF.get('/messages').then(function (r) {
      S.msgs = r.messages;
      var seen = BF.store.get('bf_seen_msg_' + S.user.id, 0), last = r.messages.length ? r.messages[r.messages.length - 1].id : 0;
      if (S.panel === 'chat' && S.chatTab === 'biz') { BF.store.set('bf_seen_msg_' + S.user.id, last); seen = last; }
      S.chatUnread = r.messages.filter(function (m) { return m.sender === 'admin' && m.id > seen; }).length;
      counts(); if (S.panel === 'chat') renderChat();
    });
  }
  function refreshAll() { return Promise.all([loadProducts(), loadCart(), loadMine(), loadNotes(), loadMsgs()]).catch(fail); }

  function counts() {
    $('#bellN').textContent = S.unread; $('#bellN').hidden = !S.unread;
    $('#cartN').textContent = S.cart.length; $('#cartN').hidden = !S.cart.length;
    $('#chatN').textContent = S.chatUnread; $('#chatN').hidden = !S.chatUnread;
  }

  /* ---------- live updates ---------- */
  function connect() {
    BF.live({
      ready: function () { refreshAll(); },
      products: function () { loadProducts().then(loadCart).catch(function () {}); },
      notification: function (n) { BF.alert(n.title, n.body); loadNotes(); },
      message: function (m) { if (m.sender === 'admin') { BF.alert('B Forward Motors replied', m.body); } loadMsgs(); },
      order: function () { loadMine(); },
      booking: function (b) { BF.alert('Booking ' + b.status, 'Your booking for the ' + b.carTitle + ' is now ' + b.status + '.'); loadMine(); }
    });
  }

  /* ---------- cars ---------- */
  function fillMakes() {
    var cur = $('#make').value, makes = {};
    S.products.forEach(function (p) { makes[p.make] = 1; });
    $('#make').innerHTML = '<option value="">All makes</option>' + Object.keys(makes).sort().map(function (m) { return '<option>' + E(m) + '</option>'; }).join('');
    $('#make').value = makes[cur] ? cur : '';
  }
  function drawCars() {
    var q = $('#q').value.trim().toLowerCase(), mk = $('#make').value, mx = +$('#max').value, so = $('#sort').value;
    var list = S.products.filter(function (p) {
      var hay = (p.year + ' ' + p.make + ' ' + p.model + ' ' + p.fuel + ' ' + p.trans + ' ' + (p.colorName || '')).toLowerCase();
      return (!q || hay.indexOf(q) > -1) && (!mk || p.make === mk) && (!mx || p.price <= mx);
    });
    list.sort(function (a, b) { return so === 'low' ? a.price - b.price : so === 'high' ? b.price - a.price : 0; });
    $('#count').textContent = S.products.length ? list.length + ' car' + (list.length === 1 ? '' : 's') + ' shown' : '';
    $('#grid').innerHTML = list.length ? list.map(function (p) { return BF.carCard(p, 'shop'); }).join('')
      : '<div class="empty" style="grid-column:1/-1"><b>' + (S.products.length ? 'No cars match' : 'New cars are coming soon') + '</b>' + (S.products.length ? 'Try a different search.' : 'You will get an alert as soon as one is posted.') + '</div>';
  }
  var qTimer;
  $('#q').addEventListener('input', function () {
    drawCars(); clearTimeout(qTimer);
    qTimer = setTimeout(function () { var v = $('#q').value.trim(); if (v.length >= 3) BF.track('search', { query: v }); }, 900);
  });
  ['#make', '#max', '#sort'].forEach(function (s) { $(s).addEventListener('change', drawCars); });
  $('#grid').addEventListener('click', function (e) {
    var b = e.target.closest('[data-act]'); if (!b) return;
    var id = +b.getAttribute('data-id'), act = b.getAttribute('data-act');
    if (act === 'view') viewCar(id); else if (act === 'cart') addToCart(id); else if (act === 'book') bookCar(id);
  });
  function car(id) { return S.products.filter(function (p) { return p.id === id; })[0]; }

  function viewCar(id) {
    var p = car(id); if (!p) return;
    BF.track('view', { productId: id });
    var free = p.status === 'available';
    var m = BF.modal(BF.carDetail(p) + '<div class="btn-row"><button class="btn btn-blue btn-lg" data-c' + (free ? '' : ' disabled') + '>' + BF.ic('cart') + 'Add to cart</button><button class="btn btn-red btn-lg" data-b' + (free ? '' : ' disabled') + '>' + BF.ic('calendar') + 'Book test drive</button></div>');
    m.querySelector('[data-c]').onclick = function () { m.close(); addToCart(id); };
    m.querySelector('[data-b]').onclick = function () { m.close(); bookCar(id); };
  }

  function addToCart(id) {
    var p = car(id); if (!p) return;
    BF.post('/cart', { productId: id }).then(function (r) {
      if (!r.added) { BF.toast('This car is already in your cart.', 'info'); return; }
      BF.track('cart', { productId: id });
      BF.toast(p.make + ' ' + p.model + ' added to your cart.');
      return loadCart().then(function () { trigger(id, 'cart'); });
    }).catch(fail);
  }

  function bookCar(id) {
    var p = car(id); if (!p) return;
    var today = new Date(Date.now() + 3 * 3600e3).toISOString().slice(0, 10);
    var m = BF.modal('<h2>Book ' + E(BF.carTitle(p)) + '</h2><p class="muted">Pick a day and time to see and test drive this car at the showroom.</p>' +
      '<form id="bkForm" novalidate><div class="form-grid"><div class="field"><label for="bkDate">Date</label><input id="bkDate" type="date" min="' + today + '" value="' + today + '"></div>' +
      '<div class="field"><label for="bkTime">Time</label><select id="bkTime">' + TIMES.map(function (t) { return '<option>' + t + '</option>'; }).join('') + '</select></div></div>' +
      '<div class="field"><label for="bkNote">Note for the team (optional)</label><textarea id="bkNote" style="min-height:70px" maxlength="300"></textarea></div><p class="err" id="bkErr" role="alert"></p>' +
      '<button class="btn btn-red btn-lg" type="submit">' + BF.ic('calendar') + 'Request booking</button></form>');
    m.querySelector('#bkForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = e.target.querySelector('button[type=submit]'); btn.disabled = true;
      BF.post('/bookings', { productId: id, date: m.querySelector('#bkDate').value, time: m.querySelector('#bkTime').value, note: m.querySelector('#bkNote').value.trim() }).then(function () {
        m.close(); BF.toast('Booking requested. We will confirm shortly.');
        return loadMine().then(function () { trigger(id, 'book'); });
      }).catch(function (err) { btn.disabled = false; if (err.status === 401) fail(err); else m.querySelector('#bkErr').textContent = err.message; });
    });
  }

  /* ---------- my bookings and orders ---------- */
  function drawMine() {
    var rows = S.bookings.map(function (x) { return '<tr><td>Booking</td><td>' + E(x.carTitle) + '</td><td>' + E(x.date + ' ' + x.time) + '</td><td>' + BF.pill(x.status) + '</td></tr>'; })
      .concat(S.orders.map(function (x) {
        return '<tr><td>Order</td><td>' + E(x.items.map(function (i) { return i.title; }).join(', ')) + '</td><td>' + M(x.total) + ' via ' + E(x.method) + '</td><td>' + BF.pill(x.status) +
          (x.status === 'awaiting_payment' ? ' <button class="btn btn-green btn-sm" data-pay="' + x.id + '">' + BF.ic('card') + 'I have paid</button>' : '') + '</td></tr>';
      }));
    $('#mine').innerHTML = rows.length ? '<table><thead><tr><th>Type</th><th>Car</th><th>Details</th><th>Status</th></tr></thead><tbody>' + rows.join('') + '</tbody></table>'
      : '<p class="muted" style="margin:0">Nothing yet. Add a car to your cart or book a test drive.</p>';
  }
  $('#mine').addEventListener('click', function (e) { var b = e.target.closest('[data-pay]'); if (b) payRef(+b.getAttribute('data-pay')); });

  function payRef(orderId) {
    var o = S.orders.filter(function (x) { return x.id === orderId; })[0]; if (!o) return;
    var m = BF.modal('<h2>Send your payment reference</h2><p class="muted">After you pay with ' + E(o.method) + ', enter the transaction ID or receipt number. The team checks it and confirms your order.</p>' +
      '<form id="prForm" novalidate><div class="field"><label for="prRef">Transaction ID or receipt number</label><input id="prRef" maxlength="80"></div><p class="err" id="prErr" role="alert"></p>' +
      '<button class="btn btn-green btn-lg" type="submit">' + BF.ic('send') + 'Send to the team</button></form>');
    m.querySelector('#prForm').addEventListener('submit', function (e) {
      e.preventDefault();
      BF.post('/orders/' + orderId + '/payment', { reference: m.querySelector('#prRef').value }).then(function () { m.close(); BF.toast('Payment reference sent.'); loadMine(); })
        .catch(function (err) { m.querySelector('#prErr').textContent = err.message; });
    });
  }

  /* ---------- side panels ---------- */
  function openPanel(name) {
    S.panel = name; $('#panel').hidden = false;
    if (name === 'cart') renderCart(); else if (name === 'notes') renderNotes(false); else if (name === 'chat') { renderChat(); markChatSeen(); }
  }
  function closePanel() { S.panel = ''; $('#panel').hidden = true; }
  function markChatSeen() { if (S.chatTab === 'biz' && S.msgs.length) { BF.store.set('bf_seen_msg_' + S.user.id, S.msgs[S.msgs.length - 1].id); S.chatUnread = 0; counts(); } }

  function renderCart() {
    $('#panelTitle').textContent = 'Your cart';
    var pays = (S.cfg && S.cfg.paymentMethods) || [];
    if (!S.cart.length) { $('#panelBody').innerHTML = '<div class="empty"><b>Your cart is empty</b>Add a car from the showroom.</div>'; $('#panelFoot').innerHTML = ''; return; }
    var total = 0;
    var lines = S.cart.map(function (p) {
      total += p.price;
      return '<div class="line"><div class="thumb">' + BF.carImg(p) + '</div><div class="grow"><b>' + E(BF.carTitle(p)) + '</b><div class="muted small">' + M(p.price) + '</div></div><button class="btn btn-ghost btn-sm" data-rm="' + p.id + '" aria-label="Remove">' + BF.ic('trash') + '</button></div>';
    }).join('');
    var payHtml = pays.length ? '<h3 style="margin-top:1.2rem">Payment method</h3>' + pays.map(function (m) {
      return '<label class="pay" style="cursor:pointer;margin-bottom:.5rem"><input type="radio" name="pm" value="' + m.id + '" ' + (S.pay === m.id ? 'checked' : '') + ' style="width:auto;margin-top:.3rem"><span><b>' + E(m.name) + '</b><span class="muted small" style="display:block;font-weight:400">' + E(m.details) + '</span></span></label>';
    }).join('') : '<p class="muted small" style="margin-top:1rem">The team will agree the payment method with you in chat.</p>';
    $('#panelBody').innerHTML = lines + payHtml + '<p class="err" id="cartErr" role="alert"></p>';
    $('#panelFoot').innerHTML = '<div style="display:flex;justify-content:space-between;margin-bottom:.7rem"><b>Total</b><b class="price" style="margin:0">' + M(total) + '</b></div><button class="btn btn-green btn-block btn-lg" id="placeBtn">' + BF.ic('check') + 'Place order</button>';
  }

  function renderNotes(keepRead) {
    $('#panelTitle').textContent = 'Notifications';
    $('#panelBody').innerHTML = S.notes.length ? S.notes.map(function (n) {
      return '<div class="note ' + (n.read ? '' : 'new') + '"><b>' + E(n.title) + '</b><span class="small muted">' + BF.fmtDate(n.createdAt) + '</span><p style="margin:.3rem 0 .4rem">' + E(n.body) + '</p>' +
        (n.productId && car(n.productId) ? '<button class="btn btn-blue btn-sm" data-view="' + n.productId + '">' + BF.ic('eye') + 'View car</button>' : '') + '</div>';
    }).join('') : '<div class="empty"><b>No notifications yet</b>New cars and offers appear here.</div>';
    var canAsk = 'Notification' in window && Notification.permission !== 'denied' && !BF.pushActive;
    $('#panelFoot').innerHTML = canAsk ? '<button class="btn btn-red btn-block" id="alertBtn">' + BF.ic('bell') + 'Turn on phone and browser alerts</button>' : '<p class="small muted" style="margin:0">' + (BF.pushActive ? 'Alerts are on for this device.' : 'New cars appear here as soon as the team posts them.') + '</p>';
    if (!keepRead && S.unread) { BF.post('/notifications/read').then(function () { S.unread = 0; counts(); }).catch(function () {}); }
  }

  /* ---------- chat: business team + assistant ---------- */
  function botKey() { return 'bf_bot_' + S.user.id; }
  function botState() { return BF.store.get(botKey(), { on: false, ctx: null, log: [] }); }
  function saveBot(st) { BF.store.set(botKey(), st); }
  function say(st, text, chips) { st.log.push({ from: 'bot', text: text, chips: chips || null, t: Date.now() }); if (st.log.length > 60) st.log = st.log.slice(-60); }

  // The assistant only starts after a customer adds a car to the cart or books one.
  function trigger(pid, kind) {
    var p = car(pid); if (!p) return;
    var st = botState(), first = S.user.name.split(' ')[0];
    st.on = true; st.ctx = { pid: pid, title: BF.carTitle(p), price: p.price, kind: kind };
    var text = kind === 'cart'
      ? 'Hi ' + first + ', I see you added the ' + st.ctx.title + ' to your cart. I can help with price, payment, test drives and delivery.'
      : 'Hi ' + first + ', your booking request for the ' + st.ctx.title + ' is in. The team will confirm the time. Anything you want to ask before then?';
    say(st, text, QUICK); saveBot(st);
    $('#botText').textContent = text; $('#botFab').hidden = false; $('#botBubble').hidden = false;
    if (S.panel === 'chat') renderChat();
  }

  function botReply(text) {
    var t = text.toLowerCase(), st = botState(), ctx = st.ctx, cfg = S.cfg || { settings: {}, paymentMethods: [] }, s = cfg.settings;
    var title = ctx ? ctx.title : 'this car';
    if (/\b(hi|hello|hey)\b/.test(t)) return { text: 'Hello. What would you like to know about ' + title + '?', chips: QUICK };
    if (/thank/.test(t)) return { text: 'You are welcome. I am here if you need anything else.', chips: QUICK };
    if (/price|cost|how much|negotiat|discount|cheap/.test(t)) return { text: (ctx ? 'The ' + title + ' is listed at ' + M(ctx.price) + '. ' : 'Each price is shown on the car card. ') + 'The sales team confirms the final price. Use "Talk to the business" to ask about it.', chips: QUICK };
    if (/pay|money|mtn|airtel|bank|deposit|cash|checkout/.test(t)) {
      var list = cfg.paymentMethods.map(function (m) { return '• ' + m.name + (m.details ? ': ' + m.details : ''); }).join('\n');
      return { text: (list ? 'You can pay with:\n' + list + '\n' : 'The team will agree the payment method with you.\n') + 'Open your cart, press Place order, pay, then use "I have paid" to send your transaction ID.', chips: QUICK };
    }
    if (/test|drive|book|view|visit|see the car|appointment/.test(t)) return { text: 'Press Book on the car, choose a date and time, and send the request. You can follow the status under "My bookings and orders".' + (s.address ? ' Showroom: ' + s.address + '.' : '') + (s.hours ? ' Hours: ' + s.hours + '.' : ''), chips: QUICK };
    if (/where|location|address|hour|open|phone|call|contact|whatsapp/.test(t)) return { text: [s.address && 'Showroom: ' + s.address, s.hours && 'Hours: ' + s.hours, s.phone && 'Phone: ' + s.phone, s.whatsapp && 'WhatsApp: +' + s.whatsapp].filter(Boolean).join('\n') || 'The team can share the showroom details in chat.', chips: QUICK };
    if (/deliver|transport|ship|transfer|ownership|document|logbook|registration/.test(t)) return { text: 'Delivery, documents and transfer of ownership are arranged by the sales team for each car. I can pass your question on.', chips: ['Talk to the business', 'Price', 'Payment options'] };
    if (/finance|loan|install|trade|exchange|warrant|guarantee|inspect|insurance/.test(t)) return { text: 'The sales team answers that for each car. I can pass your question on.', chips: ['Talk to the business', 'Price', 'Payment options'] };
    if (/human|agent|person|staff|team|business|manager|someone/.test(t)) return { handoff: true };
    return { text: 'I am not sure about that one. I can send your question to the team.', chips: ['Talk to the business', 'Price', 'Payment options'] };
  }

  function handoff(note) {
    var st = botState(), ctx = st.ctx, lastUser = '';
    st.log.forEach(function (m) { if (m.from === 'user' && m.text !== 'Talk to the business') lastUser = m.text; });
    var msg = '[Sent from the assistant]' + (ctx ? ' About the ' + ctx.title + '.' : '') + ' ' + (note || lastUser || 'Customer wants to talk to the team.');
    BF.post('/messages', { body: msg }).then(function () {
      var s2 = botState(); say(s2, 'I sent your question to the team. Their replies appear in the Business team tab.', null); saveBot(s2);
      S.chatTab = 'biz'; BF.toast('Sent to the team.'); return loadMsgs();
    }).catch(fail);
  }

  function renderChat() {
    $('#panelTitle').textContent = 'Chat';
    var st = botState(), tab = S.chatTab; if (tab === 'bot' && !st.on) tab = 'biz'; S.chatTab = tab;
    var tabs = '<div class="tabs"><button data-t="biz" class="' + (tab === 'biz' ? 'on' : '') + '">Business team</button>' + (st.on ? '<button data-t="bot" class="' + (tab === 'bot' ? 'on' : '') + '">Assistant</button>' : '') + '</div>';
    var log;
    if (tab === 'biz') {
      log = S.msgs.length ? S.msgs.map(function (m) { return '<div class="msg ' + (m.sender === 'customer' ? 'me' : 'them') + '">' + E(m.body) + '<time>' + BF.fmtTime(m.createdAt) + '</time></div>'; }).join('')
        : '<div class="msg them">Say hello. Our team replies here as soon as they can.</div>';
    } else {
      log = st.log.map(function (m, i) {
        var h = '<div class="msg ' + (m.from === 'user' ? 'me' : 'bot') + '">' + E(m.text) + '</div>';
        if (m.chips && i === st.log.length - 1) h += '<div class="chips">' + m.chips.map(function (c) { return '<button data-chip="' + E(c) + '">' + E(c) + '</button>'; }).join('') + '</div>';
        return h;
      }).join('');
    }
    var keep = $('#chatIn') ? $('#chatIn').value : '';
    $('#panelBody').innerHTML = tabs + '<div class="chatlog">' + log + '</div>';
    $('#panelFoot').innerHTML = '<form class="chat-input" id="chatForm"><input id="chatIn" placeholder="' + (tab === 'bot' ? 'Ask the assistant' : 'Message the team') + '" autocomplete="off" maxlength="1000" aria-label="Message"><button class="btn btn-green" type="submit" aria-label="Send">' + BF.ic('send') + '</button></form>';
    if (keep) $('#chatIn').value = keep;
    var b = $('#panelBody'); b.scrollTop = b.scrollHeight;
    markChatSeen();
  }
  function sendBot(text) {
    var st = botState(); st.log.push({ from: 'user', text: text, t: Date.now() });
    var r = botReply(text);
    if (r.handoff) { saveBot(st); handoff(); return; }
    say(st, r.text, r.chips); saveBot(st); renderChat();
  }

  /* ---------- panel events ---------- */
  $('#panel').addEventListener('click', function (e) {
    var t;
    if ((t = e.target.closest('[data-rm]'))) { BF.del('/cart/' + t.getAttribute('data-rm')).then(loadCart).catch(fail); return; }
    if ((t = e.target.closest('[data-view]'))) { viewCar(+t.getAttribute('data-view')); return; }
    if ((t = e.target.closest('[data-t]'))) { S.chatTab = t.getAttribute('data-t'); renderChat(); return; }
    if ((t = e.target.closest('[data-chip]'))) {
      var c = t.getAttribute('data-chip');
      if (c === 'Talk to the business') { var st = botState(); st.log.push({ from: 'user', text: c, t: Date.now() }); saveBot(st); handoff('Customer wants to talk to the team.'); }
      else sendBot(c);
      return;
    }
    if (e.target.closest('#alertBtn')) {
      BF.enableAlerts().then(function (mode) { BF.toast(mode === 'push' ? 'Alerts are on. You will hear about new cars even when the site is closed.' : 'Alerts are on while this page is open.'); renderNotes(true); }, function (err) { BF.toast(err.message, 'err'); });
      return;
    }
    if (e.target.closest('#placeBtn')) {
      var btn = $('#placeBtn'); btn.disabled = true;
      BF.post('/orders', { paymentMethodId: S.pay || undefined }).then(function (r) {
        var o = r.order, m = ((S.cfg && S.cfg.paymentMethods) || []).filter(function (x) { return x.name === o.method; })[0];
        S.panel = 'order';   // keeps the confirmation on screen while the lists refresh behind it
        $('#panelTitle').textContent = 'Order placed';
        $('#panelBody').innerHTML = '<div class="note"><b>Thank you, ' + E(S.user.name.split(' ')[0]) + '.</b><p style="margin:.3rem 0 0">Your order total is ' + M(o.total) + '. Pay with ' + E(o.method) + '.</p></div>' +
          (m ? '<p><b>' + E(m.name) + '</b><br>' + E(m.details) + '<br><span class="muted">' + E(m.note) + '</span></p>' : '') +
          '<p class="muted">Status: awaiting payment. After you pay, press "I have paid" under My bookings and orders and enter your transaction ID.</p>';
        $('#panelFoot').innerHTML = '<button class="btn btn-green btn-block btn-lg" id="toChat">' + BF.ic('chat') + 'Chat with the team</button>';
        return Promise.all([loadCart(), loadMine(), loadProducts()]);
      }).catch(function (err) {
        btn.disabled = false;
        if (err.status === 409) { loadCart(); loadProducts(); }
        var el = $('#cartErr'); if (el) el.textContent = err.message; else fail(err);
      });
      return;
    }
    if (e.target.closest('#toChat')) { S.chatTab = 'biz'; openPanel('chat'); }
  });
  $('#panel').addEventListener('change', function (e) { if (e.target.name === 'pm') S.pay = +e.target.value; });
  $('#panel').addEventListener('submit', function (e) {
    if (e.target.id !== 'chatForm') return; e.preventDefault();
    var inp = $('#chatIn'), v = inp.value.trim(); if (!v) return;
    if (S.chatTab === 'bot') { inp.value = ''; sendBot(v); }
    else { inp.value = ''; BF.post('/messages', { body: v }).then(loadMsgs).catch(fail); }
  });
})();
