/* B Forward Motors: shared browser code (API calls, icons, toasts, dialogs, live updates). */
(function () {
  'use strict';
  var BF = window.BF = {};

  /* ---------- small helpers ---------- */
  BF.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  BF.money = function (n) { return 'UGX ' + Number(n || 0).toLocaleString('en-UG'); };
  BF.fmtDate = function (t) { return new Date(t).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }); };
  BF.fmtTime = function (t) { return new Date(t).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }); };
  BF.fmtDateTime = function (t) { return BF.fmtDate(t) + ' ' + BF.fmtTime(t); };
  BF.store = {
    get: function (k, d) { try { var v = window.localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { window.localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* private mode */ } }
  };
  BF.$ = function (s, r) { return (r || document).querySelector(s); };
  BF.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var STATUS = {
    awaiting_payment: 'Awaiting payment', payment_submitted: 'Payment sent', paid: 'Paid', delivered: 'Delivered', cancelled: 'Cancelled',
    pending: 'Pending', confirmed: 'Confirmed', completed: 'Completed', available: 'Available', reserved: 'Reserved', sold: 'Sold'
  };
  BF.statusLabel = function (s) { return STATUS[s] || s; };
  BF.pill = function (s) {
    var c = /^(confirmed|paid|delivered|completed|available)$/.test(s) ? 'ok' : /^(cancelled|sold)$/.test(s) ? 'bad' : /^(pending|awaiting_payment|reserved)$/.test(s) ? 'wait' : '';
    return '<span class="status ' + c + '">' + BF.esc(BF.statusLabel(s)) + '</span>';
  };
  BF.select = function (pairs, val, attrs) {
    return '<select ' + attrs + '>' + pairs.map(function (p) { return '<option value="' + BF.esc(p[0]) + '"' + (p[0] === val ? ' selected' : '') + '>' + BF.esc(p[1]) + '</option>'; }).join('') + '</select>';
  };

  /* ---------- icons and car picture ---------- */
  var ICONS = {
    cart: '<path d="M3 4h2l2.4 10.2a1 1 0 0 0 1 .8h8.9a1 1 0 0 0 1-.8L20 8H6"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
    bell: '<path d="M6 9a6 6 0 1 1 12 0c0 6 2 7 2 7H4s2-1 2-7"/><path d="M10 20a2 2 0 0 0 4 0"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    car: '<path d="M5 16l1.5-5a2 2 0 0 1 1.9-1.4h7.2a2 2 0 0 1 1.9 1.4L19 16"/><path d="M3 16h18v3H3z"/><circle cx="7.5" cy="19" r="1"/><circle cx="16.5" cy="19" r="1"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    pin: '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    card: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/>',
    chart: '<path d="M4 20V4M4 20h16M8 16l4-5 3 3 5-7"/>',
    check: '<path d="M5 12l5 5 9-10"/>',
    send: '<path d="M21 3L10 14M21 3l-7 18-4-7-7-4z"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    logout: '<path d="M9 4H5a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h4M16 8l4 4-4 4M20 12H9"/>',
    star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5M17 11a3 3 0 1 0 0-6M22 20c0-2.5-1.8-4.2-4.5-5"/>',
    inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    home: '<path d="M3 11l9-8 9 8M5 10v10h14V10"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>'
  };
  BF.ic = function (n) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONS[n] || '') + '</svg>'; };

  BF.carSVG = function (c) {
    c = /^#[0-9a-fA-F]{6}$/.test(c || '') ? c : '#0b3d91';
    return '<svg viewBox="0 0 400 200" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Car illustration"><rect width="400" height="200" fill="#e9edf3"/>' +
      '<ellipse cx="200" cy="168" rx="150" ry="9" fill="#14181f" opacity=".13"/>' +
      '<path d="M52 146c0-12 6-20 18-24l36-10c14-16 30-30 52-30h66c22 0 36 12 52 30l30 8c14 4 20 12 20 26v8H52z" fill="' + c + '"/>' +
      '<path d="M118 110c12-14 24-26 42-26h62c18 0 30 10 44 26z" fill="#d6e4f7" opacity=".95"/><path d="M200 84v26" stroke="' + c + '" stroke-width="4"/>' +
      '<circle cx="116" cy="152" r="22" fill="#0e1013"/><circle cx="116" cy="152" r="10" fill="#c9d0da"/><circle cx="294" cy="152" r="22" fill="#0e1013"/><circle cx="294" cy="152" r="10" fill="#c9d0da"/></svg>';
  };
  BF.carTitle = function (p) { return p.year + ' ' + p.make + ' ' + p.model; };
  BF.carImg = function (p) {
    return p.hasImage ? '<img src="/api/products/' + p.id + '/image?v=' + p.imageV + '" alt="' + BF.esc(BF.carTitle(p)) + '" loading="lazy">' : BF.carSVG(p.color);
  };
  BF.brand = function () { return '<a class="brand" href="/"><span class="mark">B</span><span><b>B Forward Motors</b><small>Masaka</small></span></a>'; };

  /* ---------- API ---------- */
  BF.api = function (method, path, body) {
    var o = { method: method, credentials: 'same-origin', headers: {} };
    if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
    return fetch('/api' + path, o).then(function (r) {
      return r.text().then(function (t) {
        var data = null; try { data = t ? JSON.parse(t) : null; } catch (e) { /* not json */ }
        if (!r.ok) { var err = new Error((data && data.error) || 'Something went wrong. Please try again.'); err.status = r.status; throw err; }
        return data;
      });
    }, function () { var err = new Error('You seem to be offline. Check your connection and try again.'); err.status = 0; throw err; });
  };
  BF.get = function (p) { return BF.api('GET', p); };
  BF.post = function (p, b) { return BF.api('POST', p, b || {}); };
  BF.put = function (p, b) { return BF.api('PUT', p, b || {}); };
  BF.patch = function (p, b) { return BF.api('PATCH', p, b || {}); };
  BF.del = function (p) { return BF.api('DELETE', p); };

  var cfgP = null;
  BF.config = function () { if (!cfgP) cfgP = BF.get('/config'); return cfgP; };
  BF.refreshConfig = function () { cfgP = null; return BF.config(); };

  BF.session = function () { return BF.get('/auth/me').then(function (r) { return r.user; }); };
  BF.requireUser = function (role) {
    return BF.session().then(function (u) {
      if (!u) { location.href = '/login?next=' + encodeURIComponent(location.pathname); return null; }
      if (role && u.role !== role) { location.href = u.role === 'admin' ? '/admin' : '/shop'; return null; }
      return u;
    });
  };
  BF.logout = function () { BF.post('/auth/logout').then(function () { location.href = '/'; }, function () { location.href = '/'; }); };
  // any request that comes back 401 on a signed-in page sends the person to log in again
  BF.guard = function (err) {
    if (err && err.status === 401) { location.href = '/login?next=' + encodeURIComponent(location.pathname); return true; }
    BF.toast(err && err.message ? err.message : 'Something went wrong.', 'err'); return false;
  };

  /* ---------- toasts, dialogs ---------- */
  BF.toast = function (msg, kind) {
    var box = document.getElementById('toasts');
    if (!box) { box = document.createElement('div'); box.id = 'toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
    var t = document.createElement('div'); t.className = 'toast ' + (kind || ''); t.textContent = msg; box.appendChild(t);
    setTimeout(function () { t.remove(); }, 4500);
  };
  BF.modal = function (html, cls) {
    var o = document.createElement('div'); o.className = 'overlay';
    o.innerHTML = '<div class="modal ' + (cls || '') + '" role="dialog" aria-modal="true"><button class="modal-x btn btn-ghost btn-sm" aria-label="Close">' + BF.ic('x') + '</button>' + html + '</div>';
    document.body.appendChild(o);
    function onKey(e) { if (e.key === 'Escape') close(); }
    function close() { o.remove(); document.removeEventListener('keydown', onKey); }
    document.addEventListener('keydown', onKey);
    o.addEventListener('mousedown', function (e) { o._down = e.target === o; });
    o.addEventListener('click', function (e) { if ((e.target === o && o._down) || e.target.closest('.modal-x')) close(); });
    o.close = close;
    var first = o.querySelector('input,select,textarea'); if (first) first.focus();
    return o;
  };
  BF.confirmBox = function (text, yesLabel, cb) {
    var m = BF.modal('<h2>Please confirm</h2><p>' + BF.esc(text) + '</p><div class="btn-row"><button class="btn btn-red" data-y>' + BF.ic('check') + BF.esc(yesLabel || 'Yes') + '</button><button class="btn btn-ghost" data-n>Cancel</button></div>');
    m.querySelector('[data-y]').onclick = function () { m.close(); cb(); };
    m.querySelector('[data-n]').onclick = function () { m.close(); };
  };

  /* ---------- visitor tracking (only with permission) ---------- */
  BF.visitorId = function () {
    var v = BF.store.get('bf_vid');
    if (!v) { v = Math.random().toString(36).slice(2, 12) + Date.now().toString(36); BF.store.set('bf_vid', v); }
    return v;
  };
  BF.track = function (type, extra) {
    if (BF.store.get('bf_consent') !== 'yes') return;
    var b = { type: type, visitor: BF.visitorId() };
    if (extra) for (var k in extra) b[k] = extra[k];
    fetch('/api/track', { method: 'POST', credentials: 'same-origin', keepalive: true, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).catch(function () {});
  };
  BF.consentBanner = function () {
    if (BF.store.get('bf_consent') || document.getElementById('consent')) return;
    var d = document.createElement('div'); d.id = 'consent'; d.className = 'consent';
    d.innerHTML = '<p><b>Help us improve this website.</b> With your permission we record which cars you look at, search for and add to your cart so we can show better cars and fix problems. We never record passwords or payment details.</p>' +
      '<div class="btn-row"><button class="btn btn-green btn-sm" data-y>' + BF.ic('check') + 'Allow</button><button class="btn btn-ghost btn-sm" data-n>No thanks</button></div>';
    document.body.appendChild(d);
    d.querySelector('[data-y]').onclick = function () { BF.store.set('bf_consent', 'yes'); d.remove(); BF.track('visit'); };
    d.querySelector('[data-n]').onclick = function () { BF.store.set('bf_consent', 'no'); d.remove(); };
  };

  /* ---------- live updates (server-sent events) ---------- */
  BF.live = function (handlers) {
    if (!window.EventSource) return null;
    var es = new EventSource('/api/stream');
    Object.keys(handlers).forEach(function (k) {
      es.addEventListener(k, function (e) { var d = null; try { d = JSON.parse(e.data); } catch (x) { /* ignore */ } handlers[k](d); });
    });
    return es;
  };

  /* ---------- alerts (in page, and phone/browser push when the site is closed) ---------- */
  BF.pushActive = false;
  BF.checkPush = function () {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) return Promise.resolve(false);
    return navigator.serviceWorker.getRegistration().then(function (r) { return r ? r.pushManager.getSubscription() : null; })
      .then(function (s) { BF.pushActive = !!s; return BF.pushActive; }, function () { return false; });
  };
  function keyBytes(b64) {
    var pad = '='.repeat((4 - b64.length % 4) % 4), raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/')), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }
  BF.enableAlerts = function () {
    return BF.config().then(function (cfg) {
      if (!('Notification' in window)) throw new Error('This browser does not support alerts.');
      return Notification.requestPermission().then(function (perm) {
        if (perm !== 'granted') throw new Error('Alerts are blocked. Allow notifications for this site in your browser settings.');
        if (!cfg.vapidKey || !('serviceWorker' in navigator) || !('PushManager' in window)) return 'page';
        return navigator.serviceWorker.register('/sw.js').then(function () { return navigator.serviceWorker.ready; }).then(function (reg) {
          return reg.pushManager.getSubscription().then(function (s) { return s || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(cfg.vapidKey) }); });
        }).then(function (sub) { return BF.post('/push/subscribe', sub.toJSON()); }).then(function () { BF.pushActive = true; return 'push'; });
      });
    });
  };
  BF.alert = function (title, body) {
    BF.toast(title, 'info');
    if (document.hidden && 'Notification' in window && Notification.permission === 'granted' && !BF.pushActive) { try { new Notification(title, { body: body || '' }); } catch (e) { /* ignore */ } }
  };

  /* ---------- car cards ---------- */
  BF.carCard = function (p, mode) {
    var free = p.status === 'available';
    var tag = '<span class="tag ' + (free ? '' : p.status) + '">' + BF.esc(BF.statusLabel(p.status)) + '</span>';
    var actions = mode === 'shop'
      ? '<button class="btn btn-ghost btn-sm" data-act="view" data-id="' + p.id + '">' + BF.ic('eye') + 'Details</button>' +
        '<button class="btn btn-blue btn-sm" data-act="cart" data-id="' + p.id + '"' + (free ? '' : ' disabled') + '>' + BF.ic('cart') + 'Add to cart</button>' +
        '<button class="btn btn-red btn-sm" data-act="book" data-id="' + p.id + '"' + (free ? '' : ' disabled') + '>' + BF.ic('calendar') + 'Book</button>'
      : '<button class="btn btn-ghost btn-sm" data-act="view" data-id="' + p.id + '">' + BF.ic('eye') + 'Details</button>' +
        (free ? '<a class="btn btn-red btn-sm" href="/login?next=/shop">' + BF.ic('user') + 'Log in to buy</a>' : '');
    return '<article class="card car"><div class="car-img">' + BF.carImg(p) + tag + '</div><div class="car-body"><h3>' + BF.esc(BF.carTitle(p)) + '</h3>' +
      '<p class="meta">' + Number(p.km).toLocaleString('en-UG') + ' km &middot; ' + BF.esc(p.fuel) + ' &middot; ' + BF.esc(p.trans) + '</p><p class="price">' + BF.money(p.price) + '</p><div class="car-actions">' + actions + '</div></div></article>';
  };
  BF.carDetail = function (p) {
    return '<h2>' + BF.esc(BF.carTitle(p)) + '</h2><div class="car-img" style="border-radius:10px;margin-bottom:1rem">' + BF.carImg(p) + '</div>' +
      '<p class="price" style="font-size:1.9rem">' + BF.money(p.price) + '</p><p>' + BF.esc(p.description || '') + '</p>' +
      '<div class="spec"><div><small>Year</small><b>' + BF.esc(p.year) + '</b></div><div><small>Mileage</small><b>' + Number(p.km).toLocaleString('en-UG') + ' km</b></div>' +
      '<div><small>Fuel</small><b>' + BF.esc(p.fuel) + '</b></div><div><small>Gearbox</small><b>' + BF.esc(p.trans) + '</b></div>' +
      '<div><small>Colour</small><b>' + BF.esc(p.colorName || '-') + '</b></div><div><small>Status</small><b>' + BF.esc(BF.statusLabel(p.status)) + '</b></div></div>';
  };

  BF.readImage = function (file, max, cb) {
    var fr = new FileReader();
    fr.onload = function () {
      var im = new Image();
      im.onload = function () {
        var s = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas');
        c.width = Math.round(im.width * s); c.height = Math.round(im.height * s);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        cb(c.toDataURL('image/jpeg', 0.82));
      };
      im.onerror = function () { cb(null); };
      im.src = fr.result;
    };
    fr.onerror = function () { cb(null); };
    fr.readAsDataURL(file);
  };

  // phone / WhatsApp / email links for contact lists
  BF.contactHtml = function (s) {
    var out = [];
    if (s.address) out.push('<li>' + BF.ic('pin') + '<div><b>Showroom</b><br>' + BF.esc(s.address) + '</div></li>');
    if (s.phone) out.push('<li>' + BF.ic('phone') + '<div><b>Phone</b><br><a href="tel:' + BF.esc(s.phone.replace(/[^\d+]/g, '')) + '">' + BF.esc(s.phone) + '</a></div></li>');
    if (s.whatsapp) out.push('<li>' + BF.ic('chat') + '<div><b>WhatsApp</b><br><a href="https://wa.me/' + BF.esc(s.whatsapp) + '" target="_blank" rel="noopener">Chat on WhatsApp</a></div></li>');
    if (s.email) out.push('<li>' + BF.ic('mail') + '<div><b>Email</b><br><a href="mailto:' + BF.esc(s.email) + '">' + BF.esc(s.email) + '</a></div></li>');
    if (s.hours) out.push('<li>' + BF.ic('clock') + '<div><b>Opening hours</b><br>' + BF.esc(s.hours) + '</div></li>');
    return out.join('') || '<li class="muted">Contact details will be added soon.</li>';
  };
})();
