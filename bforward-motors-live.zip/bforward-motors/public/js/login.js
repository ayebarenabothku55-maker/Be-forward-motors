(function () {
  'use strict';
  var $ = BF.$;
  $('#brand').outerHTML = BF.brand();
  $('#c1').innerHTML = BF.ic('calendar') + 'Book test drives';
  $('#c2').innerHTML = BF.ic('bell') + 'New car alerts';
  $('#c3').innerHTML = BF.ic('chat') + 'Chat with us';
  $('#back').innerHTML = BF.ic('home') + 'Back to website';
  $('#inBtn').innerHTML = BF.ic('user') + 'Log in';
  $('#upBtn').innerHTML = BF.ic('plus') + 'Create account';
  BF.consentBanner();

  var next = new URLSearchParams(location.search).get('next');
  function go(u) {
    if (u.role === 'admin') { location.href = '/admin'; return; }
    location.href = next === '/shop' || next === '/' ? next : '/shop';
  }
  BF.session().then(function (u) { if (u) go(u); }, function () { /* show the form */ });

  function tab(up) {
    $('#tabIn').classList.toggle('on', !up); $('#tabUp').classList.toggle('on', up);
    $('#inForm').hidden = up; $('#upForm').hidden = !up;
    $(up ? '#upName' : '#inEmail').focus();
  }
  $('#tabIn').onclick = function () { tab(false); };
  $('#tabUp').onclick = function () { tab(true); };
  if (location.hash === '#signup') tab(true);

  function submit(form, btn, errEl, path, body) {
    form.addEventListener('submit', function (e) {
      e.preventDefault(); errEl.textContent = ''; btn.disabled = true;
      BF.post(path, body()).then(function (r) { go(r.user); }, function (err) { errEl.textContent = err.message; btn.disabled = false; });
    });
  }
  submit($('#inForm'), $('#inBtn'), $('#inErr'), '/auth/login', function () { return { email: $('#inEmail').value, password: $('#inPass').value }; });
  submit($('#upForm'), $('#upBtn'), $('#upErr'), '/auth/signup', function () { return { name: $('#upName').value, email: $('#upEmail').value, phone: $('#upPhone').value, password: $('#upPass').value }; });
})();
