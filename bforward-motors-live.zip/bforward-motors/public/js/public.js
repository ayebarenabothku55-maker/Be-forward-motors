(function () {
  'use strict';
  var $ = BF.$, E = BF.esc;
  var cars = [];

  BF.consentBanner();
  BF.track('visit');
  $('#brand').outerHTML = BF.brand();
  $('#yr').textContent = new Date().getFullYear();
  $('#heroArt').innerHTML = BF.carSVG('#0b3d91');
  $('#heroChips').innerHTML = ['Test drives', 'Mobile money', 'Live chat', 'New car alerts'].map(function (t, i) {
    return '<span class="chip">' + BF.ic(['calendar', 'card', 'chat', 'bell'][i]) + t + '</span>';
  }).join('');

  BF.session().then(function (u) {
    $('#authBtns').innerHTML = u
      ? '<a class="btn btn-blue btn-sm" href="' + (u.role === 'admin' ? '/admin' : '/shop') + '">' + BF.ic('user') + (u.role === 'admin' ? 'Dashboard' : 'My account') + '</a>'
      : '<a class="btn btn-red btn-sm" href="/login">' + BF.ic('user') + 'Log in / Sign up</a>';
    if (u && !$('#fbName').value) $('#fbName').value = u.name;
  }, function () {
    $('#authBtns').innerHTML = '<a class="btn btn-red btn-sm" href="/login">' + BF.ic('user') + 'Log in / Sign up</a>';
  });

  /* ---------- business details and payment methods ---------- */
  BF.config().then(function (cfg) {
    var s = cfg.settings;
    $('#topbar').innerHTML = [s.address && '<span>' + BF.ic('pin') + E(s.address) + '</span>', s.hours && '<span>' + BF.ic('clock') + E(s.hours) + '</span>',
      s.phone && '<span class="hide-s">' + BF.ic('phone') + E(s.phone) + '</span>'].filter(Boolean).join('');
    $('#contactList').innerHTML = BF.contactHtml(s);
    $('#contactBtns').innerHTML = (s.whatsapp ? '<a class="btn btn-wa" target="_blank" rel="noopener" href="https://wa.me/' + E(s.whatsapp) + '">' + BF.ic('chat') + 'WhatsApp us</a>' : '') +
      (s.phone ? '<a class="btn btn-blue" href="tel:' + E(s.phone.replace(/[^\d+]/g, '')) + '">' + BF.ic('phone') + 'Call now</a>' : '');
    $('#payList').innerHTML = cfg.paymentMethods.length ? cfg.paymentMethods.map(function (m) {
      return '<div class="pay"><span style="display:grid;place-items:center;width:44px;height:44px;border-radius:10px;background:var(--blue);color:#fff;flex:none">' + BF.ic('card') + '</span><div><b>' + E(m.name) + '</b>' +
        (m.details ? '<div class="muted">' + E(m.details) + '</div>' : '') + (m.note ? '<div class="small">' + E(m.note) + '</div>' : '') + '</div></div>';
    }).join('') : '<div class="empty"><b>Payment details are shared by our team</b>Log in and chat with us to agree how to pay.</div>';
  }, function () { /* the page still works without these details */ });

  /* ---------- cars ---------- */
  function drawCars() {
    $('#carCount').textContent = cars.length ? cars.length + ' car' + (cars.length === 1 ? '' : 's') + ' listed' : '';
    $('#carGrid').innerHTML = cars.length ? cars.map(function (p) { return BF.carCard(p, 'public'); }).join('')
      : '<div class="empty" style="grid-column:1/-1"><b>New cars are coming soon</b>Log in to get an alert the moment we post one.</div>';
  }
  function loadCars() {
    return BF.get('/products').then(function (r) { cars = r.products; drawCars(); }, function () {
      $('#carGrid').innerHTML = '<div class="empty" style="grid-column:1/-1"><b>Cars could not load</b>Check your connection and refresh the page.</div>';
    });
  }
  loadCars();
  $('#carGrid').addEventListener('click', function (e) {
    var b = e.target.closest('[data-act="view"]'); if (!b) return;
    var p = cars.filter(function (x) { return String(x.id) === b.getAttribute('data-id'); })[0]; if (!p) return;
    BF.track('view', { productId: p.id });
    BF.modal(BF.carDetail(p) + (p.status === 'available' ? '<div class="btn-row"><a class="btn btn-red btn-lg" href="/login?next=/shop">' + BF.ic('user') + 'Log in to buy</a></div>' : ''));
  });

  /* ---------- feedback ---------- */
  var rating = 5;
  function drawStars() {
    $('#stars').innerHTML = [1, 2, 3, 4, 5].map(function (n) {
      return '<button type="button" class="' + (n <= rating ? 'on' : '') + '" data-n="' + n + '" role="radio" aria-checked="' + (n === rating) + '" aria-label="' + n + ' star' + (n > 1 ? 's' : '') + '">' + BF.ic('star') + '</button>';
    }).join('');
  }
  drawStars();
  $('#stars').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) { rating = +b.getAttribute('data-n'); drawStars(); } });
  BF.get('/feedback').then(function (r) {
    $('#fbList').innerHTML = r.feedback.length ? r.feedback.map(function (x) {
      return '<div class="card pad"><b>' + E(x.name) + '</b> <span class="muted small">' + '★'.repeat(x.rating) + '</span><p style="margin:.3rem 0 0">' + E(x.text) + '</p></div>';
    }).join('') : '<p class="muted">No reviews yet. Be the first to leave one.</p>';
  }, function () { /* leave the list empty */ });
  $('#fbForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var btn = e.target.querySelector('button[type=submit]'); btn.disabled = true;
    BF.post('/feedback', { name: $('#fbName').value.trim(), rating: rating, text: $('#fbText').value.trim() }).then(function () {
      $('#fbErr').textContent = ''; $('#fbText').value = ''; BF.toast('Thank you. Your feedback was sent.');
    }, function (err) { $('#fbErr').textContent = err.message; }).then(function () { btn.disabled = false; });
  });
})();
