(function () {
  'use strict';
  var $ = BF.$, E = BF.esc, M = BF.money;
  var NAV = { dashboard: ['chart', 'Dashboard'], products: ['car', 'Products'], orders: ['calendar', 'Bookings & orders'], users: ['users', 'Users'], messages: ['inbox', 'Messages'], feedback: ['star', 'Feedback'], settings: ['settings', 'Payment & contacts'], insights: ['eye', 'Insights'] };
  var ORDER_OPTS = [['awaiting_payment', 'Awaiting payment'], ['payment_submitted', 'Payment sent'], ['paid', 'Paid'], ['delivered', 'Delivered'], ['cancelled', 'Cancelled']];
  var BOOKING_OPTS = [['pending', 'Pending'], ['confirmed', 'Confirmed'], ['completed', 'Completed'], ['cancelled', 'Cancelled']];
  var CAR_OPTS = [['available', 'Available'], ['reserved', 'Reserved'], ['sold', 'Sold']];
  var view = 'dashboard', admin = null, token = 0, activeChat = 0, convs = [], thread = [], info = { pushEnabled: false };

  BF.requireUser('admin').then(function (u) { if (u) boot(u); });

  function boot(u) {
    admin = u;
    $('#brand').outerHTML = BF.brand();
    Object.keys(NAV).forEach(function (k) {
      $('[data-v="' + k + '"]').innerHTML = BF.ic(NAV[k][0]) + NAV[k][1] + (k === 'messages' || k === 'orders' ? '<span class="badge" id="b_' + k + '" hidden>0</span>' : '');
    });
    $('#siteLink').innerHTML = BF.ic('home') + 'View website';
    $('#outLink').innerHTML = BF.ic('logout') + 'Log out';
    $('#outLink').onclick = function (e) { e.preventDefault(); BF.logout(); };
    BF.checkPush();
    BF.get('/admin/info').then(function (r) { info = r; });
    window.addEventListener('hashchange', function () { render(); window.scrollTo(0, 0); });
    BF.live({
      ready: function () { badges(); },
      badge: function (b) { BF.alert(b.text); badges(); if (view === 'orders' || view === 'dashboard') render(); },
      message: function (m) {
        if (m.sender === 'customer') BF.alert('Message from ' + (m.customerName || 'a customer'), m.body);
        badges();
        if (view === 'messages') loadConvs(m.customerId === activeChat ? true : false);
      },
      order: function () { badges(); }
    });
    render();
  }

  /* ---------- helpers ---------- */
  function head(t, sub) { return '<div class="sec-head"><div><p class="eyebrow">B Forward Motors</p><h1>' + t + '</h1></div>' + (sub ? '<p>' + sub + '</p>' : '') + '</div>'; }
  function fail(e) { BF.guard(e); }
  function badges() {
    BF.get('/admin/stats').then(function (r) {
      [['messages', r.kpis.chatsWaiting], ['orders', r.kpis.pendingBookings + r.kpis.ordersToConfirm]].forEach(function (x) { var el = $('#b_' + x[0]); if (el) { el.textContent = x[1]; el.hidden = !x[1]; } });
    }).catch(function () {});
  }
  function days(d) { var p = d.split('-'); return +p[2] + '/' + +p[1]; }

  /* line chart drawn to scale */
  function lineChart(labels, series) {
    var W = 640, H = 270, pl = 38, pr = 14, pt = 14, pb = 30, all = [];
    series.forEach(function (s) { all = all.concat(s.values); });
    var m = Math.max.apply(null, all.concat([4])), pw = Math.pow(10, Math.floor(Math.log10(m / 4)));
    var k = [1, 2, 2.5, 5, 10].filter(function (x) { return x * pw * 4 >= m; })[0], step = k * pw, top = step * 4, n = labels.length;
    var X = function (i) { return pl + i * (W - pl - pr) / (n - 1); }, Y = function (v) { return pt + (1 - v / top) * (H - pt - pb); };
    var g = '';
    for (var t = 0; t <= 4; t++) { var y = Y(t * step); g += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y + '" y2="' + y + '" stroke="#e3e7ee"/><text x="' + (pl - 6) + '" y="' + (y + 4) + '" text-anchor="end" font-size="11" fill="#5a6472">' + (t * step) + '</text>'; }
    labels.forEach(function (l, i) { if (i % 2 === 1 || i === n - 1) g += '<text x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle" font-size="11" fill="#5a6472">' + l + '</text>'; });
    series.forEach(function (s) {
      g += '<polyline points="' + s.values.map(function (v, i) { return X(i).toFixed(1) + ',' + Y(v).toFixed(1); }).join(' ') + '" fill="none" stroke="' + s.color + '" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>';
      var li = s.values.length - 1; g += '<circle cx="' + X(li) + '" cy="' + Y(s.values[li]) + '" r="4.5" fill="' + s.color + '" stroke="#fff" stroke-width="2"/>';
    });
    return '<div class="legend">' + series.map(function (s) { return '<span><i style="background:' + s.color + '"></i>' + s.name + '</span>'; }).join('') + '</div>' +
      '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Activity over the last 14 days" style="width:100%;height:auto;display:block">' + g + '</svg>';
  }
  function bars(rows, color) {
    var mx = Math.max.apply(null, rows.map(function (r) { return r[1]; }).concat([1]));
    return rows.map(function (r) { return '<div class="bar-row"><span title="' + E(r[0]) + '">' + E(r[0]) + '</span><div class="bar"><i style="width:' + (r[1] / mx * 100).toFixed(1) + '%;' + (color ? 'background:' + color : '') + '"></i></div><span>' + r[1] + '</span></div>'; }).join('') || '<p class="muted">No data yet.</p>';
  }

  /* ---------- router: each view loads its data, then draws ---------- */
  var V = {};
  function render() {
    var h = location.hash.replace('#', ''); view = V[h] ? h : 'dashboard';
    var my = ++token;
    BF.$$('.side [data-v]').forEach(function (a) { a.classList.toggle('on', a.getAttribute('data-v') === view); });
    var main = $('#main'), fresh = main.cloneNode(false); main.parentNode.replaceChild(fresh, main);   // drops old listeners
    fresh.innerHTML = head(NAV[view][1]) + '<p class="muted">Loading...</p>';
    V[view](fresh, function () { return my === token; }).catch(fail);
    badges();
  }

  /* ---------- dashboard ---------- */
  V.dashboard = function (main, live) {
    return BF.get('/admin/stats').then(function (r) {
      if (!live()) return;
      var k = r.kpis, s = r.setup;
      var items = [
        [s.hasCars, 'Upload your first car', '#products'], [s.hasContacts, 'Add your phone, WhatsApp or email', '#settings'],
        [s.hasPayments, 'Add the payment methods you accept', '#settings'], [s.pushOn, 'Phone alerts when the site is closed (needs VAPID keys, see README)', '']
      ];
      var open = items.filter(function (i) { return !i[0]; }).length;
      main.innerHTML = head('Dashboard', 'Last 14 days') +
        (open ? '<div class="card pad" style="margin-bottom:1.2rem"><h3>Finish setting up</h3><ul class="checklist">' + items.map(function (i) {
          return '<li class="' + (i[0] ? 'done' : '') + '">' + BF.ic(i[0] ? 'check' : 'x') + '<span>' + i[1] + '</span>' + (!i[0] && i[2] ? '<a class="btn btn-blue btn-sm" href="' + i[2] + '">Do it</a>' : '') + '</li>';
        }).join('') + '</ul></div>' : '') +
        '<div class="kpis"><div class="card kpi"><small>Cars for sale</small><b>' + k.carsAvailable + '</b></div>' +
        '<div class="card kpi r"><small>Pending bookings</small><b>' + k.pendingBookings + '</b></div>' +
        '<div class="card kpi r"><small>Orders to confirm</small><b>' + k.ordersToConfirm + '</b></div>' +
        '<div class="card kpi g"><small>Customers</small><b>' + k.customers + '</b></div>' +
        '<div class="card kpi k"><small>Chats waiting</small><b>' + k.chatsWaiting + '</b></div>' +
        '<div class="card kpi k"><small>Paid sales</small><b style="font-size:1.4rem">' + M(k.paidRevenue) + '</b></div></div>' +
        '<div class="card pad"><h3>Progression graph</h3>' + lineChart(r.series.map(function (d) { return days(d.day); }), [
          { name: 'Visits', color: '#0b3d91', values: r.series.map(function (d) { return d.visits; }) }, { name: 'Added to cart', color: '#14532d', values: r.series.map(function (d) { return d.carts; }) },
          { name: 'Bookings', color: '#8e1b1b', values: r.series.map(function (d) { return d.bookings; }) }, { name: 'Orders', color: '#0e1013', values: r.series.map(function (d) { return d.orders; }) }]) +
        '<p class="muted small" style="margin:.6rem 0 0">Visits and cart adds count only visitors who allowed tracking. Bookings and orders are exact.</p></div>' +
        '<div class="btn-row" style="margin-top:1rem"><a class="btn btn-blue" href="#products">' + BF.ic('upload') + 'Upload a product</a><a class="btn btn-green" href="#messages">' + BF.ic('chat') + 'Open messages</a><a class="btn btn-dark" href="#insights">' + BF.ic('eye') + 'See insights</a>' + alertBtn() + '</div>';
      wireAlerts(main);
    });
  };
  function alertBtn() { return 'Notification' in window && Notification.permission !== 'denied' && !BF.pushActive ? '<button class="btn btn-red" data-alerts>' + BF.ic('bell') + 'Turn on alerts on this device</button>' : ''; }
  function wireAlerts(main) {
    var b = main.querySelector('[data-alerts]'); if (!b) return;
    b.onclick = function () { BF.enableAlerts().then(function (mode) { BF.toast(mode === 'push' ? 'Alerts are on for this device.' : 'Alerts are on while this page is open.'); b.remove(); }, function (e) { BF.toast(e.message, 'err'); }); };
  }

  /* ---------- products ---------- */
  V.products = function (main, live) {
    return BF.get('/admin/products').then(function (r) {
      if (!live()) return;
      var ps = r.products, imgData = null;
      main.innerHTML = head('Products', 'Upload, edit and delete cars') +
        '<div class="card pad" style="margin-bottom:1.2rem"><h3 id="pfTitle">Upload a product</h3><form id="pf" novalidate>' +
        '<input type="hidden" id="pId"><div class="form-grid">' +
        '<div class="field"><label for="pMake">Make</label><input id="pMake" placeholder="Toyota" maxlength="40"></div><div class="field"><label for="pModel">Model</label><input id="pModel" placeholder="Harrier" maxlength="60"></div>' +
        '<div class="field"><label for="pYear">Year</label><input id="pYear" type="number" min="1980" max="2100" placeholder="2016"></div><div class="field"><label for="pPrice">Price (UGX)</label><input id="pPrice" type="number" min="1" placeholder="68000000"></div>' +
        '<div class="field"><label for="pKm">Mileage (km)</label><input id="pKm" type="number" min="0"></div><div class="field"><label for="pFuel">Fuel</label>' + BF.select(['Petrol', 'Diesel', 'Hybrid', 'Electric'].map(function (x) { return [x, x]; }), 'Petrol', 'id="pFuel"') + '</div>' +
        '<div class="field"><label for="pTrans">Gearbox</label>' + BF.select(['Automatic', 'Manual', '4WD Automatic', '4WD Manual'].map(function (x) { return [x, x]; }), 'Automatic', 'id="pTrans"') + '</div>' +
        '<div class="field"><label for="pColName">Colour name</label><input id="pColName" placeholder="Silver" maxlength="30"></div>' +
        '<div class="field"><label for="pCol">Colour (for the picture)</label><input id="pCol" type="color" value="#0b3d91" style="height:44px;padding:4px"></div>' +
        '<div class="field"><label for="pImg">Photo</label><input id="pImg" type="file" accept="image/*"></div></div>' +
        '<div class="field"><label for="pDesc">Product details</label><textarea id="pDesc" maxlength="2000" placeholder="Condition, service history, extras"></textarea></div>' +
        '<label id="notifyRow" style="display:flex;gap:.5rem;align-items:center;font-weight:500"><input type="checkbox" id="pNotify" checked style="width:auto"> Notify all customers about this new car</label>' +
        '<p class="err" id="pErr" role="alert"></p><div class="btn-row"><button class="btn btn-green btn-lg" type="submit" id="pSave">' + BF.ic('upload') + 'Upload product</button><button class="btn btn-ghost" type="button" id="pCancel" hidden>Cancel edit</button></div></form></div>' +
        '<div class="card pad table-wrap"><table><thead><tr><th>Car</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead><tbody>' +
        (ps.map(function (p) {
          return '<tr><td><div style="display:flex;gap:.7rem;align-items:center"><div class="thumb-sm">' + BF.carImg(p) + '</div><div><b>' + E(BF.carTitle(p)) + '</b><div class="muted small">' + Number(p.km).toLocaleString('en-UG') + ' km &middot; ' + E(p.fuel) + '</div></div></div></td><td>' + M(p.price) + '</td>' +
            '<td>' + BF.select(CAR_OPTS, p.status, 'data-st="' + p.id + '" aria-label="Status"') + '</td>' +
            '<td class="actions-cell"><div class="btn-row"><button class="btn btn-blue btn-sm" data-edit="' + p.id + '">' + BF.ic('edit') + 'Details</button><button class="btn btn-red btn-sm" data-del="' + p.id + '">' + BF.ic('trash') + 'Delete</button></div></td></tr>';
        }).join('') || '<tr><td colspan="4"><div class="empty"><b>No cars yet</b>Fill in the form above and press Upload product.</div></td></tr>') + '</tbody></table></div>';

      function reset() { $('#pf', main).reset(); $('#pId', main).value = ''; imgData = null; $('#pfTitle', main).textContent = 'Upload a product'; $('#pSave', main).innerHTML = BF.ic('upload') + 'Upload product'; $('#pCancel', main).hidden = true; $('#notifyRow', main).hidden = false; $('#pErr', main).textContent = ''; }
      $('#pCancel', main).onclick = reset;
      $('#pImg', main).onchange = function (e) {
        var f = e.target.files[0]; if (!f) return;
        BF.readImage(f, 900, function (d) { if (d) { imgData = d; $('#pErr', main).textContent = ''; } else $('#pErr', main).textContent = 'That file is not a picture.'; });
      };
      $('#pf', main).addEventListener('submit', function (e) {
        e.preventDefault();
        var id = $('#pId', main).value;
        var o = { make: $('#pMake', main).value, model: $('#pModel', main).value, year: $('#pYear', main).value, price: $('#pPrice', main).value, km: $('#pKm', main).value, fuel: $('#pFuel', main).value, trans: $('#pTrans', main).value, colorName: $('#pColName', main).value, color: $('#pCol', main).value, description: $('#pDesc', main).value };
        if (imgData) o.image = imgData;
        if (!id) o.notify = $('#pNotify', main).checked;
        var btn = $('#pSave', main); btn.disabled = true;
        (id ? BF.put('/admin/products/' + id, o) : BF.post('/admin/products', o)).then(function () {
          BF.toast(id ? 'Product updated.' : 'Product uploaded' + (o.notify ? ' and customers notified.' : '.')); render();
        }, function (err) { btn.disabled = false; if (err.status === 401) fail(err); else $('#pErr', main).textContent = err.message; });
      });
      main.addEventListener('change', function (e) {
        var s = e.target.getAttribute && e.target.getAttribute('data-st'); if (!s) return;
        BF.patch('/admin/products/' + s + '/status', { status: e.target.value }).then(function () { BF.toast('Status updated.'); }, fail);
      });
      main.addEventListener('click', function (e) {
        var ed = e.target.closest('[data-edit]'), dl = e.target.closest('[data-del]');
        if (ed) {
          var p = ps.filter(function (x) { return String(x.id) === ed.getAttribute('data-edit'); })[0]; if (!p) return;
          $('#pId', main).value = p.id; $('#pMake', main).value = p.make; $('#pModel', main).value = p.model; $('#pYear', main).value = p.year; $('#pPrice', main).value = p.price; $('#pKm', main).value = p.km;
          $('#pFuel', main).value = p.fuel; $('#pTrans', main).value = p.trans; $('#pColName', main).value = p.colorName || ''; $('#pCol', main).value = /^#[0-9a-f]{6}$/i.test(p.color) ? p.color : '#0b3d91'; $('#pDesc', main).value = p.description || '';
          imgData = null; $('#pfTitle', main).textContent = 'Edit product details'; $('#pSave', main).innerHTML = BF.ic('check') + 'Save changes'; $('#pCancel', main).hidden = false; $('#notifyRow', main).hidden = true;
          $('#pf', main).scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        if (dl) {
          var id = dl.getAttribute('data-del'), cp = ps.filter(function (x) { return String(x.id) === id; })[0];
          var held = cp && cp.status !== 'available';
          BF.confirmBox('Delete ' + (cp ? BF.carTitle(cp) : 'this car') + '? It disappears from the website and from customer carts.' + (held ? ' It is ' + cp.status + ', so any order for it keeps its record.' : ''), 'Delete product', function () {
            BF.del('/admin/products/' + id + (held ? '?force=1' : '')).then(function () { BF.toast('Product deleted.'); render(); }, fail);
          });
        }
      });
    });
  };

  /* ---------- bookings & orders ---------- */
  V.orders = function (main, live) {
    return Promise.all([BF.get('/admin/bookings'), BF.get('/admin/orders')]).then(function (r) {
      if (!live()) return;
      var bk = r[0].bookings, od = r[1].orders;
      main.innerHTML = head('Bookings & orders') +
        '<div class="card pad table-wrap" style="margin-bottom:1.2rem"><h3>Booked products</h3><table><thead><tr><th>Customer</th><th>Car</th><th>When</th><th>Note</th><th>Status</th></tr></thead><tbody>' +
        (bk.map(function (b) { return '<tr><td>' + E(b.customer) + '<div class="muted small">' + E(b.phone || '') + '</div></td><td>' + E(b.carTitle) + '</td><td>' + E(b.date + ' ' + b.time) + '</td><td>' + E(b.note || '') + '</td><td>' + BF.select(BOOKING_OPTS, b.status, 'data-bk="' + b.id + '" aria-label="Booking status"') + '</td></tr>'; }).join('') || '<tr><td colspan="5" class="muted">No bookings yet.</td></tr>') + '</tbody></table></div>' +
        '<div class="card pad table-wrap"><h3>Orders</h3><table><thead><tr><th>Customer</th><th>Cars</th><th>Total</th><th>Method / reference</th><th>Status</th></tr></thead><tbody>' +
        (od.map(function (o) { return '<tr><td>' + E(o.customer) + '<div class="muted small">' + E(o.phone || '') + '</div></td><td>' + E(o.items.map(function (i) { return i.title; }).join(', ')) + '</td><td>' + M(o.total) + '</td><td>' + E(o.method) + (o.paymentRef ? '<div class="small"><b>Ref:</b> ' + E(o.paymentRef) + '</div>' : '') + '</td><td>' + BF.select(ORDER_OPTS, o.status, 'data-od="' + o.id + '" aria-label="Order status"') + '</td></tr>'; }).join('') || '<tr><td colspan="5" class="muted">No orders yet.</td></tr>') + '</tbody></table></div>';
      main.addEventListener('change', function (e) {
        var b = e.target.getAttribute && e.target.getAttribute('data-bk'), o = e.target.getAttribute && e.target.getAttribute('data-od');
        if (b) BF.patch('/admin/bookings/' + b, { status: e.target.value }).then(function () { BF.toast('Booking updated.'); badges(); }, function (err) { fail(err); render(); });
        if (o) BF.patch('/admin/orders/' + o, { status: e.target.value }).then(function () { BF.toast('Order updated.'); badges(); }, function (err) { fail(err); render(); });
      });
    });
  };

  /* ---------- users ---------- */
  V.users = function (main, live) {
    return BF.get('/admin/users').then(function (r) {
      if (!live()) return;
      var cs = r.users;
      main.innerHTML = head('Users', cs.length + ' registered customers') +
        '<div class="card pad table-wrap" style="margin-bottom:1.2rem"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Bookings</th><th>Orders</th><th></th></tr></thead><tbody>' +
        (cs.map(function (c) { return '<tr><td>' + E(c.name) + '</td><td>' + E(c.email) + '</td><td>' + E(c.phone || '-') + '</td><td>' + BF.fmtDate(c.createdAt) + '</td><td>' + c.bookings + '</td><td>' + c.orders + '</td><td class="actions-cell"><div class="btn-row"><button class="btn btn-blue btn-sm" data-pw="' + c.id + '">' + BF.ic('key') + 'Reset password</button><button class="btn btn-red btn-sm" data-delu="' + c.id + '">' + BF.ic('trash') + 'Delete</button></div></td></tr>'; }).join('') || '<tr><td colspan="7" class="muted">No customers yet. They appear here after they sign up.</td></tr>') + '</tbody></table></div>' +
        '<div class="card pad"><h3>Send an announcement</h3><p class="muted">Shows in every customer\'s notification bell and as a phone or browser alert for customers who turned alerts on.</p><form id="annForm" novalidate>' +
        '<div class="field"><label for="annT">Title</label><input id="annT" placeholder="Weekend offer on SUVs" maxlength="80"></div><div class="field"><label for="annB">Message</label><textarea id="annB" style="min-height:80px" maxlength="300"></textarea></div><p class="err" id="annErr" role="alert"></p>' +
        '<button class="btn btn-blue" type="submit">' + BF.ic('bell') + 'Send to all customers</button></form></div>';
      main.addEventListener('click', function (e) {
        var d = e.target.closest('[data-delu]'), pw = e.target.closest('[data-pw]');
        if (d) {
          var id = d.getAttribute('data-delu'), c = cs.filter(function (x) { return String(x.id) === id; })[0];
          BF.confirmBox('Delete ' + (c ? c.name : 'this user') + '? Their account, cart and chat are removed. Cars held by their unpaid orders go back on sale.', 'Delete user', function () { BF.del('/admin/users/' + id).then(function () { BF.toast('User deleted.'); render(); }, fail); });
        }
        if (pw) {
          var uid = pw.getAttribute('data-pw'), cu = cs.filter(function (x) { return String(x.id) === uid; })[0];
          var m = BF.modal('<h2>Reset password</h2><p class="muted">Set a temporary password for ' + E(cu ? cu.name : 'this customer') + ', then tell them. They are signed out everywhere and can change it after logging in.</p><form id="rpForm" novalidate><div class="field"><label for="rpPw">New password (8 or more characters)</label><input id="rpPw" type="text" maxlength="128" autocomplete="off"></div><p class="err" id="rpErr" role="alert"></p><button class="btn btn-blue" type="submit">' + BF.ic('check') + 'Set password</button></form>');
          m.querySelector('#rpForm').addEventListener('submit', function (ev) {
            ev.preventDefault();
            BF.post('/admin/users/' + uid + '/password', { password: m.querySelector('#rpPw').value }).then(function () { m.close(); BF.toast('Password changed.'); }, function (err) { m.querySelector('#rpErr').textContent = err.message; });
          });
        }
      });
      $('#annForm', main).addEventListener('submit', function (e) {
        e.preventDefault();
        BF.post('/admin/announcements', { title: $('#annT', main).value, body: $('#annB', main).value }).then(function () { $('#annT', main).value = ''; $('#annB', main).value = ''; $('#annErr', main).textContent = ''; BF.toast('Announcement sent.'); },
          function (err) { $('#annErr', main).textContent = err.message; });
      });
    });
  };

  /* ---------- messages ---------- */
  V.messages = function (main, live) {
    main.innerHTML = head('Messages', 'Chat with customers') + '<div class="thread-list"><div class="people" id="people"></div><div class="card chatbox"><div class="chatlog" id="alog"></div><form class="chat-input" id="aForm"><input id="aIn" placeholder="Reply to customer" autocomplete="off" maxlength="1000" aria-label="Reply"><button class="btn btn-green" type="submit" aria-label="Send">' + BF.ic('send') + '</button></form></div></div>';
    $('#people', main).addEventListener('click', function (e) { var p = e.target.closest('[data-p]'); if (p) { activeChat = +p.getAttribute('data-p'); drawPeople(); loadThread(); } });
    $('#aForm', main).addEventListener('submit', function (e) {
      e.preventDefault(); var inp = $('#aIn'), v = inp.value.trim(); if (!v || !activeChat) return; inp.value = '';
      BF.post('/admin/messages/' + activeChat, { body: v }).then(function () { loadThread(); loadConvs(false); }, fail);
    });
    return loadConvs(true);
  };
  function drawPeople() {
    var el = $('#people'); if (!el) return;
    el.innerHTML = convs.map(function (c) {
      return '<button class="person ' + (c.id === activeChat ? 'on' : '') + '" data-p="' + c.id + '"><span><b>' + E(c.name) + '</b><br><span class="muted small">' + E(c.lastBody.slice(0, 34)) + '</span></span>' + (c.waiting ? '<i class="dot" title="Waiting for reply"></i>' : '') + '</button>';
    }).join('') || '<div class="empty"><b>No conversations yet</b>Customer messages appear here.</div>';
  }
  function drawLog() {
    var el = $('#alog'); if (!el) return;
    el.innerHTML = activeChat ? thread.map(function (m) { return '<div class="msg ' + (m.sender === 'customer' ? 'them' : 'me') + '">' + E(m.body) + '<time>' + BF.fmtDateTime(m.createdAt) + '</time></div>'; }).join('') : '<p class="muted">Pick a conversation.</p>';
    el.scrollTop = el.scrollHeight;
  }
  function loadConvs(reloadThread) {
    return BF.get('/admin/conversations').then(function (r) {
      convs = r.conversations;
      if (!activeChat && convs[0]) { activeChat = convs[0].id; reloadThread = true; }
      drawPeople(); if (reloadThread) loadThread(); badges();
    });
  }
  function loadThread() {
    if (!activeChat) { thread = []; drawLog(); return Promise.resolve(); }
    return BF.get('/admin/messages/' + activeChat).then(function (r) { thread = r.messages; drawLog(); }, fail);
  }

  /* ---------- feedback ---------- */
  V.feedback = function (main, live) {
    return BF.get('/admin/feedback').then(function (r) {
      if (!live()) return;
      var f = r.feedback, avg = f.length ? (f.reduce(function (s, x) { return s + x.rating; }, 0) / f.length).toFixed(1) : '-';
      main.innerHTML = head('Feedback', f.length + ' reviews, average ' + avg + ' / 5') +
        '<p class="muted">New reviews stay hidden until you approve them. Approved reviews show on the home page.</p><div class="grid">' +
        (f.map(function (x) {
          return '<div class="card pad"><b>' + E(x.name) + '</b> <span class="muted small">' + '★'.repeat(x.rating) + ' &middot; ' + BF.fmtDate(x.createdAt) + '</span> ' + BF.pill(x.approved ? 'confirmed' : 'pending').replace(/>[^<]*</, '>' + (x.approved ? 'Shown' : 'Hidden') + '<') +
            '<p style="margin:.3rem 0 .6rem">' + E(x.text) + '</p><div class="btn-row"><button class="btn ' + (x.approved ? 'btn-ghost' : 'btn-green') + ' btn-sm" data-ap="' + x.id + '" data-to="' + (x.approved ? '0' : '1') + '">' + BF.ic(x.approved ? 'x' : 'check') + (x.approved ? 'Hide' : 'Approve') + '</button><button class="btn btn-red btn-sm" data-fd="' + x.id + '">' + BF.ic('trash') + 'Delete</button></div></div>';
        }).join('') || '<div class="empty"><b>No feedback yet</b>Reviews sent from the home page appear here.</div>') + '</div>';
      main.addEventListener('click', function (e) {
        var a = e.target.closest('[data-ap]'), d = e.target.closest('[data-fd]');
        if (a) BF.patch('/admin/feedback/' + a.getAttribute('data-ap'), { approved: a.getAttribute('data-to') === '1' }).then(render, fail);
        if (d) BF.del('/admin/feedback/' + d.getAttribute('data-fd')).then(render, fail);
      });
    });
  };

  /* ---------- payment methods, company contacts, my password ---------- */
  V.settings = function (main, live) {
    return Promise.all([BF.refreshConfig()]).then(function (r) {
      if (!live()) return;
      var S = r[0].settings, pm = r[0].paymentMethods;
      main.innerHTML = head('Payment & contacts') +
        '<div class="two"><div class="card pad"><h3>Payment methods customers see</h3>' +
        (pm.map(function (m) { return '<div class="pay" style="margin-bottom:.6rem"><div style="flex:1"><b>' + E(m.name) + '</b><div class="muted small">' + E(m.details) + '</div></div><button class="btn btn-blue btn-sm" data-editpm="' + m.id + '" aria-label="Edit">' + BF.ic('edit') + '</button><button class="btn btn-red btn-sm" data-delpm="' + m.id + '" aria-label="Delete">' + BF.ic('trash') + '</button></div>'; }).join('') || '<div class="empty"><b>No payment methods yet</b>Add the ways customers can pay you.</div>') +
        '<h3 style="margin-top:1.2rem">Upload payment method</h3><form id="pmForm" novalidate><div class="field"><label for="pmName">Name</label><input id="pmName" placeholder="MTN Mobile Money" maxlength="60"></div><div class="field"><label for="pmDet">Details (number, merchant code, account)</label><input id="pmDet" maxlength="300"></div><div class="field"><label for="pmNote">Instruction for the customer</label><input id="pmNote" placeholder="Send the transaction ID in chat" maxlength="300"></div><p class="err" id="pmErr" role="alert"></p><button class="btn btn-green" type="submit">' + BF.ic('plus') + 'Add payment method</button></form></div>' +
        '<div><div class="card pad" style="margin-bottom:1.2rem"><h3>Company contacts</h3><form id="coForm" novalidate>' +
        '<div class="field"><label for="coPhone">Phone</label><input id="coPhone" value="' + E(S.phone) + '" maxlength="30"></div><div class="field"><label for="coWa">WhatsApp number with country code</label><input id="coWa" value="' + E(S.whatsapp) + '" placeholder="256700000000" maxlength="20"></div><div class="field"><label for="coEmail">Email</label><input id="coEmail" value="' + E(S.email) + '" maxlength="120"></div>' +
        '<div class="field"><label for="coAddr">Address</label><input id="coAddr" value="' + E(S.address) + '" maxlength="200"></div><div class="field"><label for="coHours">Opening hours</label><input id="coHours" value="' + E(S.hours) + '" maxlength="120"></div><p class="err" id="coErr" role="alert"></p>' +
        '<button class="btn btn-blue" type="submit">' + BF.ic('check') + 'Save contacts</button></form></div>' +
        '<div class="card pad"><h3>Change my password</h3><form id="myPw" novalidate><div class="field"><label for="mpCur">Current password</label><input id="mpCur" type="password" autocomplete="current-password" maxlength="128"></div><div class="field"><label for="mpNew">New password (8 or more characters)</label><input id="mpNew" type="password" autocomplete="new-password" maxlength="128"></div><p class="err" id="mpErr" role="alert"></p><button class="btn btn-dark" type="submit">' + BF.ic('key') + 'Change password</button></form></div></div></div>';
      main.addEventListener('click', function (e) {
        var d = e.target.closest('[data-delpm]'), ed = e.target.closest('[data-editpm]');
        if (d) BF.del('/admin/payment-methods/' + d.getAttribute('data-delpm')).then(function () { BF.toast('Payment method removed.'); render(); }, fail);
        if (ed) {
          var m0 = pm.filter(function (x) { return String(x.id) === ed.getAttribute('data-editpm'); })[0]; if (!m0) return;
          var m = BF.modal('<h2>Edit payment method</h2><form id="epForm" novalidate><div class="field"><label for="epN">Name</label><input id="epN" value="' + E(m0.name) + '" maxlength="60"></div><div class="field"><label for="epD">Details</label><input id="epD" value="' + E(m0.details) + '" maxlength="300"></div><div class="field"><label for="epT">Instruction for the customer</label><input id="epT" value="' + E(m0.note) + '" maxlength="300"></div><p class="err" id="epErr" role="alert"></p><button class="btn btn-blue" type="submit">' + BF.ic('check') + 'Save</button></form>');
          m.querySelector('#epForm').addEventListener('submit', function (ev) {
            ev.preventDefault();
            BF.put('/admin/payment-methods/' + m0.id, { name: m.querySelector('#epN').value, details: m.querySelector('#epD').value, note: m.querySelector('#epT').value }).then(function () { m.close(); BF.toast('Saved.'); render(); }, function (err) { m.querySelector('#epErr').textContent = err.message; });
          });
        }
      });
      $('#pmForm', main).addEventListener('submit', function (e) {
        e.preventDefault();
        BF.post('/admin/payment-methods', { name: $('#pmName', main).value, details: $('#pmDet', main).value, note: $('#pmNote', main).value }).then(function () { BF.toast('Payment method added.'); render(); }, function (err) { $('#pmErr', main).textContent = err.message; });
      });
      $('#coForm', main).addEventListener('submit', function (e) {
        e.preventDefault();
        BF.put('/admin/settings', { business_name: S.business_name, phone: $('#coPhone', main).value, whatsapp: $('#coWa', main).value, email: $('#coEmail', main).value, address: $('#coAddr', main).value, hours: $('#coHours', main).value })
          .then(function () { BF.toast('Contacts saved.'); $('#coErr', main).textContent = ''; BF.refreshConfig(); }, function (err) { $('#coErr', main).textContent = err.message; });
      });
      $('#myPw', main).addEventListener('submit', function (e) {
        e.preventDefault();
        BF.post('/auth/password', { current: $('#mpCur', main).value, next: $('#mpNew', main).value }).then(function () { BF.toast('Password changed.'); $('#mpCur', main).value = ''; $('#mpNew', main).value = ''; $('#mpErr', main).textContent = ''; }, function (err) { $('#mpErr', main).textContent = err.message; });
      });
    });
  };

  /* ---------- insights (data mining) ---------- */
  V.insights = function (main, live) {
    return BF.get('/admin/insights').then(function (r) {
      if (!live()) return;
      var f = r.funnel, hb = [];
      for (var h = 6; h <= 22; h++) { var row = r.hours.filter(function (x) { return x.hour === h; })[0]; hb.push([(h < 10 ? '0' : '') + h + ':00', row ? row.n : 0]); }
      main.innerHTML = head('Insights', 'Last 30 days') +
        '<p class="muted small">Views and cart adds come from visitors who allowed tracking on the website banner. Bookings and orders are exact.</p>' +
        '<div class="two"><div class="card pad"><h3>Buying funnel</h3>' + bars([['Car views', f.views], ['Added to cart', f.carts], ['Bookings', f.bookings], ['Orders', f.orders]]) + '<p class="muted small">Cart rate ' + (f.views ? Math.round(f.carts / f.views * 100) : 0) + '%. Booking rate ' + (f.views ? Math.round(f.bookings / f.views * 100) : 0) + '%.</p></div>' +
        '<div class="card pad"><h3>What people search for</h3>' + bars(r.terms.map(function (t) { return [t.term, t.n]; }), 'var(--red)') + '</div></div>' +
        '<div class="card pad" style="margin-top:1.2rem"><h3>Suggestions</h3>' + (r.tips.map(function (t) { return '<div class="suggest">' + E(t) + '</div>'; }).join('') || '<p class="muted">Suggestions appear once visitors start using the site.</p>') + '</div>' +
        '<div class="two" style="margin-top:1.2rem"><div class="card pad"><h3>Most viewed cars</h3>' + bars(r.perCar.slice(0, 8).map(function (c) { return [c.title, c.views]; })) + '</div>' +
        '<div class="card pad"><h3>Busiest hours</h3>' + bars(hb, 'var(--green)') + '</div></div>';
    });
  };
})();
