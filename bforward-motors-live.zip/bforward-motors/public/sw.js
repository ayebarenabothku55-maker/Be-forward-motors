/* Service worker: shows alerts that arrive while the website is closed. */
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });

self.addEventListener('push', function (event) {
  var d = {};
  try { d = event.data ? event.data.json() : {}; } catch (e) { d = { title: 'B Forward Motors', body: event.data ? event.data.text() : '' }; }
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      // If the site is open and visible, it already shows the alert itself.
      if (list.some(function (c) { return c.visibilityState === 'visible'; })) return;
      return self.registration.showNotification(d.title || 'B Forward Motors', {
        body: d.body || '', icon: '/favicon.svg', badge: '/favicon.svg', data: { url: d.url || '/shop' }
      });
    })
  );
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  var url = (event.notification.data && event.notification.data.url) || '/shop';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].url.indexOf(url.split('#')[0]) > -1 && 'focus' in list[i]) { list[i].navigate && list[i].navigate(url); return list[i].focus(); }
      }
      return self.clients.openWindow(url);
    })
  );
});
