'use strict';
// End-to-end test: starts the real server and drives it over HTTP.
// Use a THROWAWAY database. The test empties every table first.
//   TEST_DATABASE_URL=postgres://user:pass@localhost:5432/bf_test npm test
const assert = require('assert');
const http = require('http');

process.env.DATABASE_URL = process.env.TEST_DATABASE_URL || process.env.DATABASE_URL || '';
if (!process.env.TEST_DATABASE_URL && !process.env.BF_TEST_PGDB) {
  console.error('Set TEST_DATABASE_URL to a throwaway database. This test deletes all data in it.');
  process.exit(1);
}
process.env.SESSION_SECRET = 'test-secret-test-secret-test-secret-123456';
process.env.ADMIN_EMAIL = 'boss@bforward.test';
process.env.ADMIN_PASSWORD = 'Boss-Password-1';
process.env.NODE_ENV = 'test';

const db = require('../server/db');
const { start } = require('../server');

const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
let port, passed = 0, failed = 0;

async function call(method, path, o) {
  o = o || {};
  const headers = {};
  if (o.cookie) headers.cookie = o.cookie;
  if (o.origin) headers.origin = o.origin;
  let body;
  if (o.body !== undefined) { headers['content-type'] = o.type || 'application/json'; body = typeof o.body === 'string' ? o.body : JSON.stringify(o.body); }
  const res = await fetch('http://127.0.0.1:' + port + path, { method, headers, body });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch (e) { /* not json */ }
  const sc = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
  return { status: res.status, json, text, headers: res.headers, setCookie: sc, cookie: sc.length ? sc[0].split(';')[0] : null };
}
const get = (p, c) => call('GET', p, { cookie: c });
const post = (p, b, c) => call('POST', p, { body: b, cookie: c });
const patch = (p, b, c) => call('PATCH', p, { body: b, cookie: c });
const put = (p, b, c) => call('PUT', p, { body: b, cookie: c });
const del = (p, c) => call('DELETE', p, { cookie: c });

function stream(cookie) {
  const events = [], waiters = [];
  const req = http.get({ port, path: '/api/stream', headers: { cookie } }, (res) => {
    let buf = '';
    res.on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, i); buf = buf.slice(i + 2);
        const ev = /event: (.*)/.exec(block), da = /data: (.*)/.exec(block);
        if (ev) { const e = { event: ev[1], data: da ? JSON.parse(da[1]) : null }; events.push(e); waiters.slice().forEach((w) => w(e)); }
      }
    });
  });
  req.on('error', () => {});
  return {
    events, close: () => req.destroy(),
    wait(name, ms) {
      const from = events.length;
      return new Promise((resolve, reject) => {
        const hit = events.slice(from).filter((e) => e.event === name)[0];
        if (hit) return resolve(hit);
        const t = setTimeout(() => reject(new Error('Timed out waiting for stream event "' + name + '"')), ms || 4000);
        const w = (e) => { if (e.event === name) { clearTimeout(t); waiters.splice(waiters.indexOf(w), 1); resolve(e); } };
        waiters.push(w);
      });
    }
  };
}

async function t(name, fn) {
  try { await fn(); passed++; console.log('  ok   ' + name); }
  catch (e) { failed++; console.log('  FAIL ' + name + '\n       ' + (e && e.stack ? e.stack.split('\n').slice(0, 4).join('\n       ') : e)); }
}

(async () => {
  await db.migrate();
  await db.query('TRUNCATE users, products, cart_items, bookings, orders, order_items, notifications, messages, feedback, payment_methods, events, push_subscriptions RESTART IDENTITY CASCADE');
  const s = await start({ port: 0 });
  port = s.port;
  console.log('Server started on port ' + port);

  let admin, ann, bob, bobId, annId, carId, car2Id;

  await t('health check and static pages', async () => {
    assert.strictEqual((await get('/api/health')).json.ok, true);
    const home = await get('/');
    assert.strictEqual(home.status, 200);
    assert(/content-security-policy/i.test([...home.headers.keys()].join(',')), 'CSP header missing');
    assert.strictEqual((await get('/login')).status, 200);
    assert.strictEqual((await get('/nope-page')).status, 404);
    assert.strictEqual((await get('/..%2f..%2f..%2fetc/passwd')).status, 404);
    assert.strictEqual((await get('/server/config.js')).status, 404);
  });

  await t('public config starts with defaults and no payment methods', async () => {
    const r = (await get('/api/config')).json;
    assert.strictEqual(r.settings.business_name, 'B Forward Motors');
    assert.deepStrictEqual(r.paymentMethods, []);
    assert.deepStrictEqual((await get('/api/products')).json.products, []);
  });

  await t('admin account is created from environment and can log in', async () => {
    const bad = await post('/api/auth/login', { email: 'boss@bforward.test', password: 'wrong-password' });
    assert.strictEqual(bad.status, 401);
    const r = await post('/api/auth/login', { email: 'BOSS@bforward.test', password: 'Boss-Password-1' });
    assert.strictEqual(r.status, 200); assert.strictEqual(r.json.user.role, 'admin');
    assert(/HttpOnly/i.test(r.setCookie[0]) && /SameSite=Lax/i.test(r.setCookie[0]));
    admin = r.cookie;
    assert.strictEqual((await get('/api/auth/me', admin)).json.user.email, 'boss@bforward.test');
  });

  await t('signup validation, duplicates, login, logout', async () => {
    assert.strictEqual((await post('/api/auth/signup', { name: 'A', email: 'x@y.co', password: 'longenough1' })).status, 400);
    assert.strictEqual((await post('/api/auth/signup', { name: 'Ann Nakato', email: 'not-an-email', password: 'longenough1' })).status, 400);
    assert.strictEqual((await post('/api/auth/signup', { name: 'Ann Nakato', email: 'ann@x.co', password: 'short' })).status, 400);
    const a = await post('/api/auth/signup', { name: 'Ann Nakato', email: 'ann@x.co', phone: '+256 700 111 222', password: 'ann-password-1' });
    assert.strictEqual(a.status, 201); ann = a.cookie; annId = a.json.user.id;
    assert.strictEqual((await post('/api/auth/signup', { name: 'Ann Again', email: 'ANN@x.co', password: 'ann-password-2' })).status, 409);
    const b = await post('/api/auth/signup', { name: 'Bob Okello', email: 'bob@x.co', password: 'bob-password-1' });
    bob = b.cookie; bobId = b.json.user.id;
    assert.strictEqual((await get('/api/auth/me')).json.user, null);
    const out = await post('/api/auth/logout', {}, ann);
    assert(/Max-Age=0/.test(out.setCookie[0]));
    const again = await post('/api/auth/login', { email: 'ann@x.co', password: 'ann-password-1' });
    assert.strictEqual(again.status, 200); ann = again.cookie;
  });

  await t('access control between visitors, customers and admin', async () => {
    assert.strictEqual((await get('/api/cart')).status, 401);
    assert.strictEqual((await get('/api/admin/stats', ann)).status, 403);
    assert.strictEqual((await get('/api/cart', admin)).status, 403);
    assert.strictEqual((await get('/api/admin/stats')).status, 401);
    assert.strictEqual((await get('/api/auth/me', 'bf_session=garbage.value')).json.user, null);
  });

  await t('request hardening: cross-site origin, content type, size limit', async () => {
    assert.strictEqual((await call('POST', '/api/auth/login', { body: { email: 'a@b.co', password: 'x' }, origin: 'https://evil.example' })).status, 403);
    assert.strictEqual((await call('POST', '/api/auth/login', { body: 'email=a', type: 'application/x-www-form-urlencoded' })).status, 415);
    assert.strictEqual((await call('POST', '/api/feedback', { body: JSON.stringify({ name: 'x', rating: 5, text: 'y'.repeat(30000) }) })).status, 413);
    assert.strictEqual((await call('POST', '/api/auth/login', { body: '{broken' })).status, 400);
  });

  let ssAnn, ssAdmin;
  await t('admin uploads a car with a photo and customers are notified live', async () => {
    ssAnn = stream(ann); ssAdmin = stream(admin);
    await ssAnn.wait('ready');
    const evt = ssAnn.wait('notification');
    const r = await post('/api/admin/products', { make: 'Toyota', model: 'Harrier', year: 2016, price: 68000000, km: 62000, fuel: 'Petrol', trans: 'Automatic', colorName: 'Silver', color: '#6f7c8a', description: 'Clean car', image: PNG, notify: true }, admin);
    assert.strictEqual(r.status, 201, r.text); carId = r.json.product.id;
    assert.strictEqual(r.json.product.hasImage, true);
    const n = await evt;
    assert(/Harrier/.test(n.data.title));
    const list = (await get('/api/products')).json.products;
    assert.strictEqual(list.length, 1); assert.strictEqual(list[0].price, 68000000); assert.strictEqual(typeof list[0].price, 'number');
    assert(!('image' in list[0]));
    const img = await fetch('http://127.0.0.1:' + port + '/api/products/' + carId + '/image');
    assert.strictEqual(img.status, 200); assert.strictEqual(img.headers.get('content-type'), 'image/png');
    assert.strictEqual((await img.arrayBuffer()).byteLength, Buffer.from(PNG.split(',')[1], 'base64').length);
  });

  await t('product validation and editing', async () => {
    assert.strictEqual((await post('/api/admin/products', { make: 'X', model: 'Y', year: 1900, price: 5 }, admin)).status, 400);
    assert.strictEqual((await post('/api/admin/products', { make: 'X', model: 'Y', year: 2015, price: -5 }, admin)).status, 400);
    assert.strictEqual((await post('/api/admin/products', { make: 'X', model: 'Y', year: 2015, price: 5, image: 'data:text/html;base64,AAAA' }, admin)).status, 400);
    assert.strictEqual((await post('/api/admin/products', { make: 'Toyota', model: 'Harrier', year: 2016, price: 1 }, ann)).status, 403);
    const up = await put('/api/admin/products/' + carId, { make: 'Toyota', model: 'Harrier', year: 2016, price: 66500000, km: 63000, fuel: 'Petrol', trans: 'Automatic', description: 'Price drop' }, admin);
    assert.strictEqual(up.status, 200); assert.strictEqual(up.json.product.price, 66500000); assert.strictEqual(up.json.product.hasImage, true);
    const second = await post('/api/admin/products', { make: 'Subaru', model: 'Forester', year: 2014, price: 49000000, km: 88000, fuel: 'Petrol', trans: 'Automatic' }, admin);
    car2Id = second.json.product.id;
    assert.strictEqual(second.json.product.hasImage, false);
    assert.strictEqual((await get('/api/products/' + car2Id + '/image')).status, 404);
  });

  await t('notifications: unread counts, mark read, announcements', async () => {
    let n = (await get('/api/notifications', ann)).json;
    assert.strictEqual(n.notifications.length, 1);
    await post('/api/notifications/read', {}, ann);
    n = (await get('/api/notifications', ann)).json; assert.strictEqual(n.unread, 0);
    const evt = ssAnn.wait('notification');
    assert.strictEqual((await post('/api/admin/announcements', { title: 'Weekend offer', body: 'SUVs on offer this weekend.' }, admin)).status, 201);
    await evt;
    n = (await get('/api/notifications', ann)).json; assert.strictEqual(n.unread, 1);
    assert.strictEqual((await post('/api/admin/announcements', { title: '', body: 'x' }, admin)).status, 400);
  });

  await t('chat between customer and business, live both ways', async () => {
    const toAdmin = ssAdmin.wait('message');
    const m = await post('/api/messages', { body: 'Is the Harrier still available?' }, ann);
    assert.strictEqual(m.status, 201);
    assert.strictEqual((await toAdmin).data.customerName, 'Ann Nakato');
    const conv = (await get('/api/admin/conversations', admin)).json.conversations;
    assert.strictEqual(conv.length, 1); assert.strictEqual(conv[0].waiting, true);
    assert.strictEqual((await get('/api/admin/stats', admin)).json.kpis.chatsWaiting, 1);
    const toAnn = ssAnn.wait('message');
    assert.strictEqual((await post('/api/admin/messages/' + annId, { body: 'Yes it is. Come and see it.' }, admin)).status, 201);
    assert.strictEqual((await toAnn).data.sender, 'admin');
    const thread = (await get('/api/messages', ann)).json.messages;
    assert.deepStrictEqual(thread.map((x) => x.sender), ['customer', 'admin']);
    assert.strictEqual((await get('/api/admin/conversations', admin)).json.conversations[0].waiting, false);
    assert.strictEqual((await post('/api/messages', { body: '   ' }, ann)).status, 400);
    assert.strictEqual((await get('/api/admin/messages/' + annId, ann)).status, 403);
  });

  await t('cart rules', async () => {
    assert.strictEqual((await post('/api/cart', { productId: carId }, ann)).json.added, true);
    assert.strictEqual((await post('/api/cart', { productId: carId }, ann)).json.added, false);
    assert.strictEqual((await post('/api/cart', { productId: 9999 }, ann)).status, 404);
    assert.strictEqual((await get('/api/cart', ann)).json.cart.length, 1);
    assert.strictEqual((await del('/api/cart/' + carId, ann)).status, 200);
    assert.strictEqual((await get('/api/cart', ann)).json.cart.length, 0);
  });

  await t('two buyers racing for one car: exactly one wins', async () => {
    await post('/api/cart', { productId: carId }, ann); await post('/api/cart', { productId: carId }, bob);
    const [a, b] = await Promise.all([post('/api/orders', {}, ann), post('/api/orders', {}, bob)]);
    const codes = [a.status, b.status].sort();
    assert.deepStrictEqual(codes, [201, 409], 'got ' + codes + ' ' + a.text + ' ' + b.text);
    const car = (await get('/api/products')).json.products.filter((p) => p.id === carId)[0];
    assert.strictEqual(car.status, 'reserved');
    assert.strictEqual((await post('/api/cart', { productId: carId }, bob)).status, 409);
    const winner = a.status === 201 ? a : b;
    assert.strictEqual(winner.json.order.total, 66500000);
    assert.strictEqual(winner.json.order.status, 'awaiting_payment');
    assert.strictEqual(winner.json.order.items[0].title, '2016 Toyota Harrier');
    assert.strictEqual(winner.json.order.method, 'To be agreed with the team');
    t.orderId = winner.json.order.id; t.winner = a.status === 201 ? ann : bob; t.loser = a.status === 201 ? bob : ann;
  });

  await t('payment methods, payment reference and order confirmation', async () => {
    assert.strictEqual((await post('/api/admin/payment-methods', { name: 'MTN Mobile Money', details: 'Merchant code 123456', note: 'Send the transaction ID' }, admin)).status, 201);
    assert.strictEqual((await get('/api/config')).json.paymentMethods.length, 1);
    assert.strictEqual((await post('/api/orders/' + t.orderId + '/payment', { reference: 'ab' }, t.winner)).status, 400);
    assert.strictEqual((await post('/api/orders/' + t.orderId + '/payment', { reference: 'MP240101.1234.A12345' }, t.loser)).status, 404, 'cannot touch someone else\'s order');
    assert.strictEqual((await post('/api/orders/' + t.orderId + '/payment', { reference: 'MP240101.1234.A12345' }, t.winner)).status, 200);
    let orders = (await get('/api/admin/orders', admin)).json.orders;
    assert.strictEqual(orders[0].status, 'payment_submitted'); assert.strictEqual(orders[0].paymentRef, 'MP240101.1234.A12345');
    const evt = (t.winner === ann ? ssAnn : null);
    const wait = evt ? evt.wait('order') : null;
    assert.strictEqual((await patch('/api/admin/orders/' + t.orderId, { status: 'paid' }, admin)).status, 200);
    if (wait) assert.strictEqual((await wait).data.status, 'paid');
    assert.strictEqual((await get('/api/products')).json.products.filter((p) => p.id === carId)[0].status, 'sold');
    assert.strictEqual((await patch('/api/admin/orders/' + t.orderId, { status: 'cancelled' }, admin)).status, 200);
    assert.strictEqual((await get('/api/products')).json.products.filter((p) => p.id === carId)[0].status, 'available');
    assert.strictEqual((await patch('/api/admin/orders/' + t.orderId, { status: 'delivered' }, admin)).status, 200);
    assert.strictEqual((await get('/api/products')).json.products.filter((p) => p.id === carId)[0].status, 'sold');
    assert.strictEqual((await patch('/api/admin/orders/' + t.orderId, { status: 'nonsense' }, admin)).status, 400);
    const mine = (await get('/api/orders', t.winner)).json.orders; assert.strictEqual(mine.length, 1);
    assert.strictEqual((await get('/api/orders', t.loser)).json.orders.length, 0);
    assert.strictEqual((await del('/api/admin/products/' + carId, admin)).status, 409, 'sold car needs force');
    assert.strictEqual((await del('/api/admin/products/' + carId + '?force=1', admin)).status, 200);
    orders = (await get('/api/admin/orders', admin)).json.orders;
    assert.strictEqual(orders[0].items[0].title, '2016 Toyota Harrier', 'sales record survives car deletion');
  });

  await t('bookings: validation, creation, admin update, live status', async () => {
    const past = '2020-01-01';
    assert.strictEqual((await post('/api/bookings', { productId: car2Id, date: past, time: '10:00' }, ann)).status, 400);
    assert.strictEqual((await post('/api/bookings', { productId: car2Id, date: '2099-01-01', time: '10:00' }, ann)).status, 400);
    const d = new Date(Date.now() + 3 * 3600e3 + 2 * 864e5).toISOString().slice(0, 10);
    assert.strictEqual((await post('/api/bookings', { productId: car2Id, date: d, time: '03:33' }, ann)).status, 400);
    const toAdmin = ssAdmin.wait('badge');
    const b = await post('/api/bookings', { productId: car2Id, date: d, time: '10:00', note: 'Coming with my brother' }, ann);
    assert.strictEqual(b.status, 201, b.text);
    assert.strictEqual((await toAdmin).data.kind, 'booking');
    const list = (await get('/api/admin/bookings', admin)).json.bookings;
    assert.strictEqual(list[0].customer, 'Ann Nakato'); assert.strictEqual(list[0].carTitle, '2014 Subaru Forester'); assert.strictEqual(list[0].date, d);
    const evt = ssAnn.wait('booking');
    assert.strictEqual((await patch('/api/admin/bookings/' + list[0].id, { status: 'confirmed' }, admin)).status, 200);
    assert.strictEqual((await evt).data.status, 'confirmed');
    assert.strictEqual((await get('/api/bookings', ann)).json.bookings[0].status, 'confirmed');
    assert.strictEqual((await get('/api/bookings', bob)).json.bookings.length, 0);
  });

  await t('feedback is held until approved', async () => {
    assert.strictEqual((await post('/api/feedback', { name: 'Visitor', rating: 5, text: 'Great service' })).status, 200);
    assert.strictEqual((await post('/api/feedback', { name: 'Visitor', rating: 9, text: 'Great service' })).status, 400);
    assert.strictEqual((await get('/api/feedback')).json.feedback.length, 0);
    const all = (await get('/api/admin/feedback', admin)).json.feedback;
    assert.strictEqual(all.length, 1); assert.strictEqual(all[0].approved, false);
    await patch('/api/admin/feedback/' + all[0].id, { approved: true }, admin);
    assert.strictEqual((await get('/api/feedback')).json.feedback.length, 1);
    await del('/api/admin/feedback/' + all[0].id, admin);
    assert.strictEqual((await get('/api/feedback')).json.feedback.length, 0);
  });

  await t('tracking, dashboard numbers and insights', async () => {
    for (let i = 0; i < 12; i++) await post('/api/track', { type: 'view', productId: car2Id, visitor: 'v' + i });
    for (let i = 0; i < 4; i++) await post('/api/track', { type: 'search', query: 'Pickup', visitor: 'v' + i });
    await post('/api/track', { type: 'visit', visitor: 'v1' }, ann);
    await post('/api/track', { type: 'cart', productId: car2Id, visitor: 'v1' }, ann);
    assert.strictEqual((await post('/api/track', { type: 'hack', visitor: 'v1' })).status, 400);
    assert.strictEqual((await post('/api/track', { type: 'view', productId: 99999, visitor: 'v1' })).status, 204, 'unknown car id is ignored, not an error');
    const st = (await get('/api/admin/stats', admin)).json;
    assert.strictEqual(st.series.length, 14);
    assert.strictEqual(st.series[13].visits, 1); assert.strictEqual(st.series[13].bookings, 1); assert.strictEqual(st.series[13].orders, 1);
    assert.strictEqual(st.kpis.customers, 2); assert.strictEqual(st.kpis.paidRevenue, 66500000);
    assert.strictEqual(st.setup.hasCars, true); assert.strictEqual(st.setup.hasPayments, true); assert.strictEqual(st.setup.hasContacts, false);
    const ins = (await get('/api/admin/insights', admin)).json;
    assert.strictEqual(ins.funnel.views, 13); assert.strictEqual(ins.funnel.carts, 1); assert.strictEqual(ins.funnel.bookings, 1);
    assert.strictEqual(ins.terms[0].term, 'pickup');
    assert(ins.tips.some((x) => /pickup/.test(x)), 'tip about unmet search expected: ' + JSON.stringify(ins.tips));
    assert(ins.tips.some((x) => /views happen around/.test(x)));
    assert.strictEqual(ins.perCar[0].title, '2014 Subaru Forester');
  });

  await t('company settings validation', async () => {
    assert.strictEqual((await put('/api/admin/settings', { business_name: 'B Forward Motors', phone: 'abc' }, admin)).status, 400);
    assert.strictEqual((await put('/api/admin/settings', { business_name: 'B Forward Motors', whatsapp: '123' }, admin)).status, 400);
    const r = await put('/api/admin/settings', { business_name: 'B Forward Motors Masaka', phone: '+256 700 123 456', whatsapp: '+256 700 123 456', email: 'sales@bforward.test', address: 'Masaka Town', hours: 'Mon-Sat 8-6' }, admin);
    assert.strictEqual(r.status, 200); assert.strictEqual(r.json.settings.whatsapp, '256700123456');
    assert.strictEqual((await get('/api/config')).json.settings.business_name, 'B Forward Motors Masaka');
  });

  await t('password change signs out other sessions; admin reset; rate limit', async () => {
    const second = await post('/api/auth/login', { email: 'bob@x.co', password: 'bob-password-1' });
    assert.strictEqual((await post('/api/auth/password', { current: 'nope-nope-1', next: 'bob-password-2' }, bob)).status, 400);
    const ch = await post('/api/auth/password', { current: 'bob-password-1', next: 'bob-password-2' }, bob);
    assert.strictEqual(ch.status, 200); const fresh = ch.cookie;
    assert.strictEqual((await get('/api/auth/me', second.cookie)).json.user, null, 'old session must stop working');
    assert.strictEqual((await get('/api/auth/me', fresh)).json.user.email, 'bob@x.co');
    assert.strictEqual((await post('/api/admin/users/' + bobId + '/password', { password: 'reset-by-admin-1' }, admin)).status, 200);
    assert.strictEqual((await get('/api/auth/me', fresh)).json.user, null);
    assert.strictEqual((await post('/api/auth/login', { email: 'bob@x.co', password: 'reset-by-admin-1' })).status, 200);
    let last = 0;
    for (let i = 0; i < 12; i++) last = (await post('/api/auth/login', { email: 'victim@x.co', password: 'guess-' + i })).status;
    assert.strictEqual(last, 429);
  });

  await t('deleting a customer releases unpaid cars and removes their chat', async () => {
    await post('/api/cart', { productId: car2Id }, ann);
    assert.strictEqual((await post('/api/orders', { paymentMethodId: 999 }, ann)).status, 400, 'unknown payment method');
    const o = await post('/api/orders', { paymentMethodId: 1 }, ann); assert.strictEqual(o.status, 201, o.text);
    assert.strictEqual((await get('/api/products')).json.products.filter((p) => p.id === car2Id)[0].status, 'reserved');
    assert.strictEqual((await del('/api/admin/users/' + annId, admin)).status, 200);
    assert.strictEqual((await get('/api/products')).json.products.filter((p) => p.id === car2Id)[0].status, 'available');
    assert.strictEqual((await get('/api/auth/me', ann)).json.user, null);
    assert.strictEqual((await get('/api/admin/conversations', admin)).json.conversations.length, 0);
    const orders = (await get('/api/admin/orders', admin)).json.orders;
    assert(orders.some((x) => x.customer === 'Ann Nakato' && x.status === 'cancelled'), 'order record kept with the customer name');
    assert.strictEqual((await del('/api/admin/users/' + 1, admin)).status, 404, 'admins cannot be deleted');
  });

  ssAnn.close(); ssAdmin.close();
  await s.close();
  console.log('\n' + passed + ' passed, ' + failed + ' failed');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('Test run crashed:', e); process.exit(1); });
